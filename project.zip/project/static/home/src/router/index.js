import Vue from 'vue';
import VueRouter from 'vue-router';
import index from '../views/index.vue'
import login from '../views/account/login.vue';
Vue.use(VueRouter)

const routes = [
	// 主页
	{
		path: '/',
		name: 'index',
		component: index
	},
	// 登录
	{
		path: '/account/login',
		name: 'login',
		component: login
	},
	// 忘记密码
	{
		path: '/account/forgot',
		name: 'forgot',
		component: () => import('../views/account/forgot.vue')
	},
	// 注册账号
	{
		path: '/account/register',
		name: 'register',
		component: () => import('../views/account/register.vue')
	},
		// 媒体图片
	{
		path: '/media/image',
		name: 'media_image',
		component: () => import('../views/media/image.vue')
	},
	// 音乐
	{
		path: '/media/music',
		name: 'media_music',
		component: () => import('../views/media/music.vue')
	},
	// 媒体视频
	{
		path: '/media/video',
		name: 'media_video',
		component: () => import('../views/media/video.vue')
	},
	// 媒体视频
	{
		path: '/user_center/index',
		name: 'user_center_index',
		component: () => import('../views/user_center/index.vue')
	},
	// 文章路由
	{
		path: '/article/list',
		name: 'article_list',
		component: () => import('../views/article/list.vue')
	},
	{
		path: '/article/details',
		name: 'article_details',
		component: () => import('../views/article/details.vue')
	},
	// 浏览网站
	// 收藏路由
	{
		path: '/user/collect',
		name: 'collect_list',
		component: () => import('../views/user/collect.vue')
	},


	{
		path: '/comment/table',
		name: 'comment_table',
		component: () => import('../views/comment/table.vue')
	},
	{
		path: '/comment/view',
		name: 'comment_view',
		component: () => import('../views/comment/view.vue')
	},

		// 考试路由
	{
		path: '/subject_exam/list',
		name: 'exam_list',
		component: () => import('../views/subject_exam/list.vue')
	},
	{
		path: '/subject_exam/details',
		name: 'exam_details',
		component: () => import('../views/subject_exam/details.vue')
	},
	// 错题路由
	{
		path: '/subject_exam/answer_wrong_table',
		name: 'exam_answer_wrong_table',
		component: () => import('../views/subject_exam/answer_wrong_table.vue')
	},
	{
		path: '/subject_exam/answer_wrong_view',
		name: 'exam_answer_wrong_view',
		component: () => import('../views/subject_exam/answer_wrong_view.vue')
	},
	



	// 公告路由
	{
		path: '/notice/list',
		name: 'notice_list',
		component: () => import('../views/notice/list.vue')
	},
	{
		path: '/notice/details',
		name: 'notice_details',
		component: () => import('../views/notice/details.vue')
	},
	// 教师用户表格路由
	{
		path: '/teacher_user/table',
		name: '/teacher_user_table',
		component: () => import('../views/teacher_user/table.vue')
	},
	// 教师用户详情路由
	{
		path: '/teacher_user/view',
		name: '/teacher_user_view',
		component: () => import('../views/teacher_user/view.vue')
	},
	
	
		
		
		
	// 学生用户表格路由
	{
		path: '/student_users/table',
		name: '/student_users_table',
		component: () => import('../views/student_users/table.vue')
	},
	// 学生用户详情路由
	{
		path: '/student_users/view',
		name: '/student_users_view',
		component: () => import('../views/student_users/view.vue')
	},
	
	
		
		
		
	// 课程信息表格路由
	{
		path: '/course_information/table',
		name: '/course_information_table',
		component: () => import('../views/course_information/table.vue')
	},
	// 课程信息详情路由
	{
		path: '/course_information/view',
		name: '/course_information_view',
		component: () => import('../views/course_information/view.vue')
	},
	
		// 课程信息列表路由
	{
		path: '/course_information/list',
		name: '/course_information_list',
		component: () => import('../views/course_information/list.vue')
	},
	
		// 课程信息详情路由
	{
		path: '/course_information/details',
		name: '/course_information_details',
		component: () => import('../views/course_information/details.vue')
	},
		
		
		
	// 班级信息表格路由
	{
		path: '/class_information/table',
		name: '/class_information_table',
		component: () => import('../views/class_information/table.vue')
	},
	// 班级信息详情路由
	{
		path: '/class_information/view',
		name: '/class_information_view',
		component: () => import('../views/class_information/view.vue')
	},
	
	
		
		
		
	// 课程类型表格路由
	{
		path: '/course_type/table',
		name: '/course_type_table',
		component: () => import('../views/course_type/table.vue')
	},
	// 课程类型详情路由
	{
		path: '/course_type/view',
		name: '/course_type_view',
		component: () => import('../views/course_type/view.vue')
	},
	
	
		
		
		
	// 选课申请表格路由
	{
		path: '/application_for_course_selection/table',
		name: '/application_for_course_selection_table',
		component: () => import('../views/application_for_course_selection/table.vue')
	},
	// 选课申请详情路由
	{
		path: '/application_for_course_selection/view',
		name: '/application_for_course_selection_view',
		component: () => import('../views/application_for_course_selection/view.vue')
	},
		// 选课申请添加路由
	{
		path: '/application_for_course_selection/edit',
		name: '/application_for_course_selection_edit',
		component: () => import('../views/application_for_course_selection/edit.vue')
	},
	
	
		
		
		
	// 选课信息表格路由
	{
		path: '/course_selection_information/table',
		name: '/course_selection_information_table',
		component: () => import('../views/course_selection_information/table.vue')
	},
	// 选课信息详情路由
	{
		path: '/course_selection_information/view',
		name: '/course_selection_information_view',
		component: () => import('../views/course_selection_information/view.vue')
	},
	
	
		
		
		
	// 提问信息表格路由
	{
		path: '/question_information/table',
		name: '/question_information_table',
		component: () => import('../views/question_information/table.vue')
	},
	// 提问信息详情路由
	{
		path: '/question_information/view',
		name: '/question_information_view',
		component: () => import('../views/question_information/view.vue')
	},
	
	
		
		
		
	// 回答信息表格路由
	{
		path: '/answer_information/table',
		name: '/answer_information_table',
		component: () => import('../views/answer_information/table.vue')
	},
	// 回答信息详情路由
	{
		path: '/answer_information/view',
		name: '/answer_information_view',
		component: () => import('../views/answer_information/view.vue')
	},
	
	
		
		
		
	// 课程反馈表格路由
	{
		path: '/course_feedback/table',
		name: '/course_feedback_table',
		component: () => import('../views/course_feedback/table.vue')
	},
	// 课程反馈详情路由
	{
		path: '/course_feedback/view',
		name: '/course_feedback_view',
		component: () => import('../views/course_feedback/view.vue')
	},
	
	
		
		
		
	// 课程作业表格路由
	{
		path: '/course_work/table',
		name: '/course_work_table',
		component: () => import('../views/course_work/table.vue')
	},
	// 课程作业详情路由
	{
		path: '/course_work/view',
		name: '/course_work_view',
		component: () => import('../views/course_work/view.vue')
	},
	
	
		
		
		
	// 完成作业表格路由
	{
		path: '/finish_the_job/table',
		name: '/finish_the_job_table',
		component: () => import('../views/finish_the_job/table.vue')
	},
	// 完成作业详情路由
	{
		path: '/finish_the_job/view',
		name: '/finish_the_job_view',
		component: () => import('../views/finish_the_job/view.vue')
	},
	
	
		
		
		
	// 作业批改表格路由
	{
		path: '/homework_correction/table',
		name: '/homework_correction_table',
		component: () => import('../views/homework_correction/table.vue')
	},
	// 作业批改详情路由
	{
		path: '/homework_correction/view',
		name: '/homework_correction_view',
		component: () => import('../views/homework_correction/view.vue')
	},
	
	
		
		
		
	// 评估记录表格路由
	{
		path: '/assessment_record/table',
		name: '/assessment_record_table',
		component: () => import('../views/assessment_record/table.vue')
	},
	// 评估记录详情路由
	{
		path: '/assessment_record/view',
		name: '/assessment_record_view',
		component: () => import('../views/assessment_record/view.vue')
	},
	
	
		
		
		
	// 进度记录表格路由
	{
		path: '/progress_records/table',
		name: '/progress_records_table',
		component: () => import('../views/progress_records/table.vue')
	},
	// 进度记录详情路由
	{
		path: '/progress_records/view',
		name: '/progress_records_view',
		component: () => import('../views/progress_records/view.vue')
	},
	
	
		
		
		
	// 资料信息表格路由
	{
		path: '/information/table',
		name: '/information_table',
		component: () => import('../views/information/table.vue')
	},
	// 资料信息详情路由
	{
		path: '/information/view',
		name: '/information_view',
		component: () => import('../views/information/view.vue')
	},
	
		// 资料信息列表路由
	{
		path: '/information/list',
		name: '/information_list',
		component: () => import('../views/information/list.vue')
	},
	
		// 资料信息详情路由
	{
		path: '/information/details',
		name: '/information_details',
		component: () => import('../views/information/details.vue')
	},
		
		
		
	// 资料类型表格路由
	{
		path: '/data_type/table',
		name: '/data_type_table',
		component: () => import('../views/data_type/table.vue')
	},
	// 资料类型详情路由
	{
		path: '/data_type/view',
		name: '/data_type_view',
		component: () => import('../views/data_type/view.vue')
	},
	
	
		
		
		
	// 口语录音表格路由
	{
		path: '/oral_recording/table',
		name: '/oral_recording_table',
		component: () => import('../views/oral_recording/table.vue')
	},
	// 口语录音详情路由
	{
		path: '/oral_recording/view',
		name: '/oral_recording_view',
		component: () => import('../views/oral_recording/view.vue')
	},
	
	
		
		
		

	// 用户路由
	{
		path: '/user/index',
		name: 'user_index',
		component: () => import('../views/user/index.vue')
	},
	// 基本信息
	{
		path: '/user/info',
		name: 'user_info',
		component: () => import('../views/user/info.vue')
	},
	// 找回密码
	{
		path: '/user/password',
		name: 'user_password',
		component: () => import('../views/user/password.vue')
	},

	// 搜索
	{
		path: '/search',
		name: 'search',
		component: () => import('../views/search/index.vue')
	},
	// 局部搜索
	{
		path: '/search/details',
		name: 'search_details',
		component: () => import('../views/search/details.vue')
	}
]

const router = new VueRouter({
	mode: 'hash',
	base: process.env.BASE_URL,
	routes
})

router.afterEach((to, from, next) => {
	let title = "在线英语口语学习平台-home";
	document.title = title;
	document.logo = "在线英语口语学习平台"
})

export default router
