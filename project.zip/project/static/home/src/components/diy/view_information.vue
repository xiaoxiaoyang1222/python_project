<template>
	<el-main class="bg edit_wrap">
		<el-form ref="form" :model="form" status-icon label-width="120px" v-if="is_view()">
		<el-row class="row_ce">
							<el-col v-if="$check_field('get','data_name') || $check_field('add','data_name') || $check_field('set','data_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="资料名称" prop="data_name">
												<el-input id="data_name" v-model="form['data_name']" placeholder="请输入资料名称"
							  v-if="(form['information_id'] && $check_field('set','data_name')) || (!form['information_id'] && $check_field('add','data_name'))" :disabled="disabledObj['data_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','data_name')">{{form['data_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','data_type') || $check_field('add','data_type') || $check_field('set','data_type')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="资料类型" prop="data_type">
								<el-select id="data_type" v-model="form['data_type']"						v-if="(form['information_id'] && $check_field('set','data_type')) || (!form['information_id'] && $check_field('add','data_type'))">
						<el-option v-for="o in list_data_type" :key="o['data_type']" :label="o['data_type']"
							:value="o['data_type']">
						</el-option>
					</el-select>
					<div v-else-if="$check_field('get','data_type')">{{form['data_type']}}</div>
							</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','cover_image') || $check_field('add','cover_image') || $check_field('set','cover_image')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="封面图" prop="cover_image">
								<el-upload :disabled="disabledObj['cover_image_isDisabled']" class="avatar-uploader" drag
						accept="image/gif, image/jpeg, image/png, image/jpg" action="" :http-request="upload_cover_image"
						:show-file-list="false" v-if="(form['information_id'] && $check_field('set','cover_image')) || (!form['information_id'] && $check_field('add','cover_image'))">
						<img id="cover_image" v-if="form['cover_image']" :src="$fullUrl(form['cover_image'])" class="avatar">
						<i v-else class="el-icon-plus avatar-uploader-icon"></i>
					</el-upload>
					<el-image v-else-if="$check_field('get','cover_image')" style="width: 100px; height: 100px"
						:src="$fullUrl(form['cover_image'])" :preview-src-list="[$fullUrl(form['cover_image'])]">
						<div slot="error" class="image-slot">
							<img src="../../../public/img/error.png" style="width: 90px; height: 90px" />
						</div>
					</el-image>
							</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','source') || $check_field('add','source') || $check_field('set','source')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="资料来源" prop="source">
												<el-input id="source" v-model="form['source']" placeholder="请输入资料来源"
							  v-if="(form['information_id'] && $check_field('set','source')) || (!form['information_id'] && $check_field('add','source'))" :disabled="disabledObj['source_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','source')">{{form['source']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','information_annex') || $check_field('add','information_annex') || $check_field('set','information_annex')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="资料附件" prop="information_annex">
												<div v-if="disabledObj['information_annex_isDisabled']">
						<div v-if="$check_field('get','information_annex')">
							<el-button type="primary" @click="$download($fullUrl(form['information_annex']),form['information_annex'])">下载<i
									class="el-icon-download el-icon--right"></i></el-button>
						</div>
					</div>
					<div v-else>
						<el-upload v-if="(form['information_id'] && $check_field('set','information_annex')) || (!form['information_id'] && $check_field('add','information_annex'))" class="upload-demo" drag
								   action="" style="max-width: 300px;width: 100%;" :http-request="upload_information_annex" :limit="1" accept="">
							<i class="el-icon-upload"></i>
							<div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
						</el-upload>
						<div v-else-if="$check_field('get','information_annex')">
							<el-button type="primary" @click="$download($fullUrl(form['information_annex']),form['information_annex'])">下载<i
									class="el-icon-download el-icon--right"></i></el-button>
						</div>
					</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','upload_personnel') || $check_field('add','upload_personnel') || $check_field('set','upload_personnel')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="上传人员" prop="upload_personnel">
																		<div v-if="user_group !== '管理员'">
							{{ get_user_session_upload_personnel(form['upload_personnel']) }}
							<el-select v-if="(form['information_id'] && $check_field('set','upload_personnel')) || (!form['information_id'] && $check_field('add','upload_personnel'))" id="upload_personnel" v-model="form['upload_personnel']" :disabled="disabledObj['upload_personnel_isDisabled']">
								<el-option v-for="o in list_user_upload_personnel" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
										   :value="o['user_id']">
								</el-option>
							</el-select>
							<el-select v-else-if="$check_field('get','upload_personnel')" id="upload_personnel" v-model="form['upload_personnel']" :disabled="true">
								<el-option v-for="o in list_user_upload_personnel" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
										   :value="o['user_id']">
								</el-option>
							</el-select>
						</div>
						<el-select v-else id="upload_personnel" v-model="form['upload_personnel']" :disabled="disabledObj['upload_personnel_isDisabled']">
							<el-option v-for="o in list_user_upload_personnel" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
																</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','information_introduction') || $check_field('add','information_introduction') || $check_field('set','information_introduction')" :xs="24" :sm="24" :lg="24" class="el_form_editor_warp">
				<el-form-item label="资料介绍" prop="information_introduction">
					<quill-editor v-model.number="form['information_introduction']"
						v-if="(form['information_id'] && $check_field('set','information_introduction')) || (!form['information_id'] && $check_field('add','information_introduction')) ">
					</quill-editor>
					<div v-else-if="$check_field('get','information_introduction')" v-html="form['information_introduction']"></div>
				</el-form-item>
			</el-col>
						
	
	
		
		
	
	
	
	
	</el-row>
			<el-col :xs="24" :sm="12" :lg="8" class="el_form_btn_warp">
				<el-form-item v-if="$check_action('/information/view','set') || $check_action('/information/view','add') || $check_option('/information/table','examine')">
					<el-button type="primary" @click="submit()">提交</el-button>
					<el-button @click="cancel()">取消</el-button>
				</el-form-item>
				<el-form-item v-else>
					<el-button @click="cancel()">返回</el-button>
				</el-form-item>
			</el-col>

		</el-form>
	</el-main>
</template>

<script>
	import mixin from "@/mixins/page.js";

	export default {
		mixins: [mixin],
		data() {
			return {
				field: "information_id",
				url_add: "~/api/information/add?",
				url_set: "~/api/information/set?",
				url_get_obj: "~/api/information/get_obj?",
				url_upload: "~/api/information/upload?",

				query: {
					"information_id": 0,
				},

				form: {
								"data_name":  '', // 资料名称
										"data_type":  '', // 资料类型
										"cover_image":  '', // 封面图
										"source":  '', // 资料来源
										"information_annex":  '', // 资料附件
										"upload_personnel": 0, // 上传人员
										"information_introduction":  '', // 资料介绍
											"information_id": 0, // ID
													},
				disabledObj:{
								"data_name_isDisabled": false,
										"data_type_isDisabled": false,
										"cover_image_isDisabled": false,
										"source_isDisabled": false,
										"information_annex_isDisabled": false,
										"upload_personnel_isDisabled": false,
										"information_introduction_isDisabled": false,
										},

	
										// 资料类型选项列表
				list_data_type: [""],
	
				
				
				
				
					// 用户列表
				list_user_upload_personnel: [],
						// 用户组
				group_user_upload_personnel: "",
						
			
			}
		},
		methods: {

	
	
			
				/**
			 * 获取资料类型列表
			 */
			async get_list_data_type() {
				var json = await this.$get("~/api/data_type/get_list?");
				if(json.result && json.result.list){
					this.list_data_type = json.result.list;
				}
				else if(json.error){
					console.error(json.error);
				}
			},
					
						/**
			 * 上传封面图
			 * @param {Object} param 图片参数
			 */
			upload_cover_image(param){
									this.uploadFile(param.file, "cover_image");
								},
	
	
			
	
						/**
			 * 上传资料附件
			 * @param {Object} param 文件参数
			 */
			upload_information_annex(param){
									this.uploadFile(param.file, "information_annex");
								},
	
	
			
	
				/**
			 * 获取教师用户用户列表
			 */
			async get_list_user_upload_personnel() {
                var json = await this.$get("~/api/user/get_list?user_group=教师用户");
                if(json.result && json.result.list){
                    this.list_user_upload_personnel = json.result.list;
                }
                else if(json.error){
                    console.error(json.error);
                }
			},
					/**
			 * 获取教师用户用户组
			 */
			async get_group_user_upload_personnel() {
							this.form["upload_personnel"] = this.$store.state.user.user_id;
							var json = await this.$get("~/api/user_group/get_obj?name=教师用户");
				if(json.result && json.result.obj){
					this.group_user_upload_personnel = json.result.obj;
				}
				else if(json.error){
					console.error(json.error);
				}
			},
			get_user_session_upload_personnel(id){
				var _this = this;
				var user_id = {"user_id":id}
				var url = "~/api/"+_this.group_user_upload_personnel.source_table+"/get_obj?"
				this.$get(url, user_id, function(res) {
					if (res.result && res.result.obj) {
						var arr = []
						for (let key in res.result.obj) {
							arr.push(key)
						}
						var arrForm = []
									for (let key in _this.form) {
							arrForm.push(key)
						}
												_this.form["upload_personnel"] = id
									_this.disabledObj['upload_personnel' + '_isDisabled'] = true
						for (var i=0;i<arr.length;i++){
						  if (arr[i]!=='examine_state' && arr[i]!=='examine_reply') {
							for (var j = 0; j < arrForm.length; j++) {
							  if (arr[i] === arrForm[j]) {
								if (arr[i] !== "upload_personnel") {
			                      _this.form[arrForm[j]] = res.result.obj[arr[i]]
			                      _this.disabledObj[arrForm[j] + '_isDisabled'] = true
								  break;
								} else {
								  _this.disabledObj[arrForm[j] + '_isDisabled'] = true
								}
							  }
							}
						  }
						}
					}
				});
			},
					get_user_upload_personnel(id){
				var obj = this.list_user_upload_personnel.getObj({"user_id":id});
				var ret = "";
				if(obj){
					if(obj.nickname){
						ret = obj.nickname;}
					else{
						ret = obj.username;
					}
				}
				return ret;
			},
			
	
		
			/**
			 * 获取对象之前
			 * @param {Object} param
			 */
			get_obj_before(param) {
				var form = "";
																																																							if(this.form && form){
					Object.keys(this.form).forEach(key => {
						Object.keys(form).forEach(dbKey => {
							// if(dbKey === "charging_standard"){
							// 	this.form['charging_rules'] = form[dbKey];
							// 	this.disabledObj['charging_rules_isDisabled'] = true;
							// };
							if(key === dbKey){
								this.disabledObj[key+'_isDisabled'] = true;
								this.form[key] = form[dbKey]
							}
							if(dbKey === "source_table"){
								this.form['source_table'] = form[dbKey];
							}
							if(dbKey === "source_id"){
								this.form['source_id'] = form[dbKey];
							}
							if(dbKey === "source_user_id"){
								this.form['source_user_id'] = form[dbKey];
							}
						})
					})
				}
																		$.db.del("form");
				return param;
			},

			/**
			 * 获取对象之后
			 * @param {Object} json
			 * @param {Object} func
			 */
			get_obj_after(json, func){

																																			

			},

																																																							async submit(param, func){
				if (!param) {
					param = this.form;
				}
								var pm = this.events("submit_before", Object.assign({}, param)) || param;
				var msg = await this.events("submit_check", pm);
				var ret;
				if (msg) {
					this.$toast(msg, 'danger');
				} else {
																																																									ret = this.events("submit_main", pm, func);
				}
				return ret;
			},
			/**
			 * 提交前验证事件
			 * @param {Object} 请求参数
			 * @return {String} 验证成功返回null, 失败返回错误提示
			 */
						submit_check(param) {
																																																																																							return null;
			},

			is_view(){
				// var bl = this.user_group == "管理员";
				var bl = false;

				if(!bl){
					bl = this.$check_action('/information/table','add');
					console.log(bl ? "你有表格添加权限视作有添加权限" : "你没有表格添加权限");
				}
				if(!bl){
					bl = this.$check_action('/information/table','set');
					console.log(bl ? "你有表格添加权限视作有修改权限" : "你没有表格修改权限");
				}
				if(!bl){
					bl = this.$check_action('/information/view','add');
					console.log(bl ? "你有视图添加权限视作有添加权限" : "你没有视图添加权限");
				}
				if(!bl){
					bl = this.$check_action('/information/view','set');
					console.log(bl ? "你有视图修改权限视作有修改权限" : "你没有视图修改权限");
				}
				if(!bl){
					bl = this.$check_action('/information/view','get');
					console.log(bl ? "你有视图查询权限视作有查询权限" : "你没有视图查询权限");
				}

				console.log(bl ? "具有当前页面的查看权，请注意这不代表你有字段的查看权" : "无权查看当前页，请注意即便有字段查询权限没有页面查询权限也不行");

				return bl;
			},
			/**
			 * 上传文件
			 * @param {Object} param
			 */
			uploadimg(param) {
				this.uploadFile(param.file, "avatar");
			},

		},
		created() {
						this.get_list_data_type();
													this.get_list_user_upload_personnel();
					this.get_group_user_upload_personnel();
							},
	}
</script>

<style>
	.avatar-uploader .el-upload {
		border: 1px dashed #d9d9d9;
		border-radius: 6px;
		cursor: pointer;
		position: relative;
		overflow: hidden;
	}

	.avatar-uploader .el-upload:hover {
		border-color: #409EFF;
	}

	.avatar-uploader-icon {
		font-size: 28px;
		color: #8c939d;
		width: 178px;
		height: 178px;
		line-height: 178px;
		text-align: center;
	}

	.avatar {
		width: 178px;
		height: 178px;
		display: block;
	}
	
	.img_multiple{
		overflow: hidden;
	}
	.img_multiple .img_block{
		float: left;
		margin-right: 5px;
		margin-bottom: 5px;
		position: relative;
	}
	.img_multiple .img_block img{
		height: 100px;
		width: auto;
	}
	.img_multiple .img_del{
		position: absolute;
		top: 5px;
		right: 5px;
		width: 20px;
		height: 20px;
		background: #0000008a;
		color: #fff;
		line-height: 20px;
		text-align: center;
		border-radius: 100%;
		cursor: pointer;
	}




</style>
