<template>
  <div class="list_menu diy_menu">
    <router-link
            to="/user_center/index"
            class="menu_item"
            :class="{ selected: this.$route.path=== '/user_center/index'}"
     >
      <span class="left_span">个人首页</span>
      <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
    </router-link>
          <router-link
          to="/teacher_user/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/teacher_user/table'}"
          v-if="$check_action('/teacher_user/table','get')">
        <span class="left_span">教师用户</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/student_users/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/student_users/table'}"
          v-if="$check_action('/student_users/table','get')">
        <span class="left_span">学生用户</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/course_information/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/course_information/table'}"
          v-if="$check_action('/course_information/table','get')">
        <span class="left_span">课程信息</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/class_information/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/class_information/table'}"
          v-if="$check_action('/class_information/table','get')">
        <span class="left_span">班级信息</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/course_type/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/course_type/table'}"
          v-if="$check_action('/course_type/table','get')">
        <span class="left_span">课程类型</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/application_for_course_selection/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/application_for_course_selection/table'}"
          v-if="$check_action('/application_for_course_selection/table','get')">
        <span class="left_span">选课申请</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/course_selection_information/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/course_selection_information/table'}"
          v-if="$check_action('/course_selection_information/table','get')">
        <span class="left_span">选课信息</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/question_information/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/question_information/table'}"
          v-if="$check_action('/question_information/table','get')">
        <span class="left_span">提问信息</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/answer_information/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/answer_information/table'}"
          v-if="$check_action('/answer_information/table','get')">
        <span class="left_span">回答信息</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/course_feedback/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/course_feedback/table'}"
          v-if="$check_action('/course_feedback/table','get')">
        <span class="left_span">课程反馈</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/course_work/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/course_work/table'}"
          v-if="$check_action('/course_work/table','get')">
        <span class="left_span">课程作业</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/finish_the_job/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/finish_the_job/table'}"
          v-if="$check_action('/finish_the_job/table','get')">
        <span class="left_span">完成作业</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/homework_correction/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/homework_correction/table'}"
          v-if="$check_action('/homework_correction/table','get')">
        <span class="left_span">作业批改</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/assessment_record/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/assessment_record/table'}"
          v-if="$check_action('/assessment_record/table','get')">
        <span class="left_span">评估记录</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/progress_records/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/progress_records/table'}"
          v-if="$check_action('/progress_records/table','get')">
        <span class="left_span">进度记录</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/information/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/information/table'}"
          v-if="$check_action('/information/table','get')">
        <span class="left_span">资料信息</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/data_type/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/data_type/table'}"
          v-if="$check_action('/data_type/table','get')">
        <span class="left_span">资料类型</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
              <router-link
          to="/oral_recording/table"
          class="menu_item"
          :class="{ selected: this.$route.path=== '/oral_recording/table'}"
          v-if="$check_action('/oral_recording/table','get')">
        <span class="left_span">口语录音</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
      </router-link>
        <router-link
        to="/subject_exam/answer_wrong_table"
        class="menu_item"
        :class="{ selected: this.$route.path=== '/subject_exam/answer_wrong_table'}"
        v-if="$check_action('/user_answer_wrong/table','get')">
      <span class="left_span">错题记录</span>
      <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
    </router-link>
  <router-link
              to="/user/collect"
              class="menu_item"
              :class="{ selected: this.$route.path=== '/user/collect'}"
              v-if="$check_action('/collect/list','get')">
        <span class="left_span">收藏</span>
        <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
  </router-link>
	<router-link
	            to="/comment/table"
	            class="menu_item"
	            :class="{ selected: this.$route.path=== '/comment/table'}"
	            v-if="$check_action('/comment/table','get')">
	      <span class="left_span">评论管理</span>
	      <span class="right_span"><b-icon icon="house-fill"></b-icon></span>
	</router-link>
  </div>
</template>

<script>
import mixin from "@/mixins/page.js";
export default {
  mixins: [mixin],
  data() {
    return {
    };
  },
  mounted() {
  },
  methods: {
  },

  components: {
  },
};
</script>

<style scoped>
.list_menu {
  flex: 0 0 25%;
  border-bottom: 1px solid #eee;
}
.menu_item {
  display: flex;
  justify-content: space-between;
  padding: 15px 20px;
  border: 1px solid #eee;
  border-bottom: none;
  background-color: #fff;
}
.menu_item.selected {
  background-color: #000;
}
.menu_item.selected span {
  color: #fff ;
}
.content {
  flex: 0 0 74%;
}
</style>
