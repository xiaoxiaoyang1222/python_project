<template>
	<el-main class="bg edit_wrap">
		<el-form ref="form" :model="form" status-icon label-width="120px" v-if="is_view()">
		<el-row class="row_ce">
							<el-col v-if="$check_field('get','course_number') || $check_field('add','course_number') || $check_field('set','course_number')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="课程编号" prop="course_number">
												<el-input id="course_number" v-model="form['course_number']" placeholder="请输入课程编号"
							  v-if="(form['course_feedback_id'] && $check_field('set','course_number')) || (!form['course_feedback_id'] && $check_field('add','course_number'))" :disabled="disabledObj['course_number_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','course_number')">{{form['course_number']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','course_name') || $check_field('add','course_name') || $check_field('set','course_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="课程名称" prop="course_name">
												<el-input id="course_name" v-model="form['course_name']" placeholder="请输入课程名称"
							  v-if="(form['course_feedback_id'] && $check_field('set','course_name')) || (!form['course_feedback_id'] && $check_field('add','course_name'))" :disabled="disabledObj['course_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','course_name')">{{form['course_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','course_type') || $check_field('add','course_type') || $check_field('set','course_type')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="课程类型" prop="course_type">
												<el-input id="course_type" v-model="form['course_type']" placeholder="请输入课程类型"
							  v-if="(form['course_feedback_id'] && $check_field('set','course_type')) || (!form['course_feedback_id'] && $check_field('add','course_type'))" :disabled="disabledObj['course_type_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','course_type')">{{form['course_type']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','course_duration') || $check_field('add','course_duration') || $check_field('set','course_duration')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="课程时间" prop="course_duration">
												<el-input id="course_duration" v-model="form['course_duration']" placeholder="请输入课程时间"
							  v-if="(form['course_feedback_id'] && $check_field('set','course_duration')) || (!form['course_feedback_id'] && $check_field('add','course_duration'))" :disabled="disabledObj['course_duration_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','course_duration')">{{form['course_duration']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','class_name') || $check_field('add','class_name') || $check_field('set','class_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="班级名称" prop="class_name">
												<el-input id="class_name" v-model="form['class_name']" placeholder="请输入班级名称"
							  v-if="(form['course_feedback_id'] && $check_field('set','class_name')) || (!form['course_feedback_id'] && $check_field('add','class_name'))" :disabled="disabledObj['class_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','class_name')">{{form['class_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','course_teacher') || $check_field('add','course_teacher') || $check_field('set','course_teacher')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="课程教师" prop="course_teacher">
													<el-select v-if="(form['course_feedback_id'] && $check_field('set','course_teacher')) || (!form['course_feedback_id'] && $check_field('add','course_teacher'))" id="course_teacher" v-model="form['course_teacher']" :disabled="disabledObj['course_teacher_isDisabled']">
							<el-option v-for="o in list_user_course_teacher" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
						<el-select v-else-if="$check_field('get','course_teacher')" id="course_teacher" v-model="form['course_teacher']" :disabled="true">
							<el-option v-for="o in list_user_course_teacher" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','teacher_id') || $check_field('add','teacher_id') || $check_field('set','teacher_id')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="教师工号" prop="teacher_id">
												<el-input id="teacher_id" v-model="form['teacher_id']" placeholder="请输入教师工号"
							  v-if="(form['course_feedback_id'] && $check_field('set','teacher_id')) || (!form['course_feedback_id'] && $check_field('add','teacher_id'))" :disabled="disabledObj['teacher_id_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','teacher_id')">{{form['teacher_id']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','teachers_name') || $check_field('add','teachers_name') || $check_field('set','teachers_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="教师姓名" prop="teachers_name">
												<el-input id="teachers_name" v-model="form['teachers_name']" placeholder="请输入教师姓名"
							  v-if="(form['course_feedback_id'] && $check_field('set','teachers_name')) || (!form['course_feedback_id'] && $check_field('add','teachers_name'))" :disabled="disabledObj['teachers_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','teachers_name')">{{form['teachers_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','student_users') || $check_field('add','student_users') || $check_field('set','student_users')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="学生用户" prop="student_users">
													<el-select v-if="(form['course_feedback_id'] && $check_field('set','student_users')) || (!form['course_feedback_id'] && $check_field('add','student_users'))" id="student_users" v-model="form['student_users']" :disabled="disabledObj['student_users_isDisabled']">
							<el-option v-for="o in list_user_student_users" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
						<el-select v-else-if="$check_field('get','student_users')" id="student_users" v-model="form['student_users']" :disabled="true">
							<el-option v-for="o in list_user_student_users" :key="o['username']" :label="o['nickname'] + '-' + o['username']"
									   :value="o['user_id']">
							</el-option>
						</el-select>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','student_name') || $check_field('add','student_name') || $check_field('set','student_name')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="学生姓名" prop="student_name">
												<el-input id="student_name" v-model="form['student_name']" placeholder="请输入学生姓名"
							  v-if="(form['course_feedback_id'] && $check_field('set','student_name')) || (!form['course_feedback_id'] && $check_field('add','student_name'))" :disabled="disabledObj['student_name_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','student_name')">{{form['student_name']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','student_gender') || $check_field('add','student_gender') || $check_field('set','student_gender')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="学生性别" prop="student_gender">
												<el-input id="student_gender" v-model="form['student_gender']" placeholder="请输入学生性别"
							  v-if="(form['course_feedback_id'] && $check_field('set','student_gender')) || (!form['course_feedback_id'] && $check_field('add','student_gender'))" :disabled="disabledObj['student_gender_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','student_gender')">{{form['student_gender']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','mobile_phone_number') || $check_field('add','mobile_phone_number') || $check_field('set','mobile_phone_number')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="手机号码" prop="mobile_phone_number">
												<el-input id="mobile_phone_number" v-model="form['mobile_phone_number']" placeholder="请输入手机号码"
							  v-if="(form['course_feedback_id'] && $check_field('set','mobile_phone_number')) || (!form['course_feedback_id'] && $check_field('add','mobile_phone_number'))" :disabled="disabledObj['mobile_phone_number_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','mobile_phone_number')">{{form['mobile_phone_number']}}</div>
											</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','feedback_content') || $check_field('add','feedback_content') || $check_field('set','feedback_content')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="反馈内容" prop="feedback_content">
								<el-input type="textarea" id="feedback_content" v-model="form['feedback_content']" placeholder="请输入反馈内容"
						v-if="(form['course_feedback_id'] && $check_field('set','feedback_content')) || (!form['course_feedback_id'] && $check_field('add','feedback_content'))" :disabled="disabledObj['feedback_content_isDisabled']"></el-input>
					<div v-else-if="$check_field('get','feedback_content')">{{form['feedback_content']}}</div>
							</el-form-item>
			</el-col>
								<el-col v-if="$check_field('get','feedback_date') || $check_field('add','feedback_date') || $check_field('set','feedback_date')" :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="反馈日期" prop="feedback_date">
								<el-date-picker :disabled="disabledObj['feedback_date_isDisabled']" v-if="(form['course_feedback_id'] && $check_field('set','feedback_date')) || (!form['course_feedback_id'] && $check_field('add','feedback_date'))" id="feedback_date"
						v-model="form['feedback_date']" type="date" placeholder="选择日期" value-format="yyyy-MM-dd">
					</el-date-picker>
					<div v-else-if="$check_field('get','feedback_date')">{{form['feedback_date']}}</div>
							</el-form-item>
			</el-col>
								<el-col :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="审核状态" prop="examine_state">
					<el-select id="examine_state" v-model="form['examine_state']"
						v-if="(form['examine_state'] && $check_examine()) || (!form['examine_state'] && $check_examine())" :disabled="true">
						<el-option key="未审核" label="未审核" value="未审核"></el-option>
						<el-option key="已通过" label="已通过" value="已通过"></el-option>
						<el-option key="未通过" label="未通过" value="未通过"></el-option>
					</el-select>
					<div v-else>{{form["examine_state"]}}</div>
				</el-form-item>
			</el-col>
					<el-col :xs="24" :sm="12" :lg="8" class="el_form_item_warp">
				<el-form-item label="审核回复" prop="examine_reply">
					<el-input id="examine_reply" v-model="form['examine_reply']" placeholder="请输入审核回复"
						v-if="(form['examine_reply'] && $check_examine()) || (!form['examine_reply'] && $check_examine())" :disabled="true"></el-input>
					<div v-else>{{form["examine_reply"]}}</div>
				</el-form-item>
			</el-col>
	
	
	
		
		
	
	
	
	
	</el-row>
			<el-col :xs="24" :sm="12" :lg="8" class="el_form_btn_warp">
				<el-form-item v-if="$check_action('/course_feedback/view','set') || $check_action('/course_feedback/view','add') || $check_option('/course_feedback/table','examine')">
					<el-button type="primary" @click="submit()">提交</el-button>
					<el-button @click="cancel()">取消</el-button>
				</el-form-item>
				<el-form-item v-else>
					<el-button @click="cancel()">返回</el-button>
				</el-form-item>
			</el-col>

		</el-form>
	</el-main>
</template>

<script>
	import mixin from "@/mixins/page.js";

	export default {
		mixins: [mixin],
		data() {
			return {
				field: "course_feedback_id",
				url_add: "~/api/course_feedback/add?",
				url_set: "~/api/course_feedback/set?",
				url_get_obj: "~/api/course_feedback/get_obj?",
				url_upload: "~/api/course_feedback/upload?",

				query: {
					"course_feedback_id": 0,
				},

				form: {
								"course_number":  '', // 课程编号
										"course_name":  '', // 课程名称
										"course_type":  '', // 课程类型
										"course_duration":  '', // 课程时间
										"class_name":  '', // 班级名称
										"course_teacher": 0, // 课程教师
										"teacher_id":  '', // 教师工号
										"teachers_name":  '', // 教师姓名
										"student_users": 0, // 学生用户
										"student_name": '', // 学生姓名
										"student_gender": '', // 学生性别
										"mobile_phone_number": '', // 手机号码
										"feedback_content": '', // 反馈内容
										"feedback_date":  '', // 反馈日期
									"examine_state": "未审核",
							"examine_reply": "",
							"course_feedback_id": 0, // ID
													},
				disabledObj:{
								"course_number_isDisabled": false,
										"course_name_isDisabled": false,
										"course_type_isDisabled": false,
										"course_duration_isDisabled": false,
										"class_name_isDisabled": false,
										"course_teacher_isDisabled": false,
										"teacher_id_isDisabled": false,
										"teachers_name_isDisabled": false,
										"student_users_isDisabled": false,
										"student_name_isDisabled": false,
										"student_gender_isDisabled": false,
										"mobile_phone_number_isDisabled": false,
										"feedback_content_isDisabled": false,
										"feedback_date_isDisabled": false,
										},

	
				
				
				
				
				
					// 用户列表
				list_user_course_teacher: [],
						
				
				
					// 用户列表
				list_user_student_users: [],
						
				
				
				
				
			
			}
		},
		methods: {

	
	
			
	
			
	
			
	
			
	
			
	
				/**
			 * 获取教师用户用户列表
			 */
			async get_list_user_course_teacher() {
                var json = await this.$get("~/api/user/get_list?user_group=教师用户");
                if(json.result && json.result.list){
                    this.list_user_course_teacher = json.result.list;
                }
                else if(json.error){
                    console.error(json.error);
                }
			},
					get_user_course_teacher(id){
				var obj = this.list_user_course_teacher.getObj({"user_id":id});
				var ret = "";
				if(obj){
					if(obj.nickname){
						ret = obj.nickname;}
					else{
						ret = obj.username;
					}
				}
				return ret;
			},
			
	
			
	
			
	
				/**
			 * 获取学生用户用户列表
			 */
			async get_list_user_student_users() {
                var json = await this.$get("~/api/user/get_list?user_group=学生用户");
                if(json.result && json.result.list){
                    this.list_user_student_users = json.result.list;
                }
                else if(json.error){
                    console.error(json.error);
                }
			},
					get_user_student_users(id){
				var obj = this.list_user_student_users.getObj({"user_id":id});
				var ret = "";
				if(obj){
					if(obj.nickname){
						ret = obj.nickname;}
					else{
						ret = obj.username;
					}
				}
				return ret;
			},
			
	
			
	
			
	
			
	
			
	
		
			/**
			 * 获取对象之前
			 * @param {Object} param
			 */
			get_obj_before(param) {
				var form = "";
																						// 获取缓存数据附加
				form = $.db.get("form");
						if(form != null){
					if("examine_state" in form){
						delete form.examine_state
					}
								if("examine_reply" in form){
						delete form.examine_reply
					}
							}
									$.push(this.form ,form);
																																										if(this.form && form){
					Object.keys(this.form).forEach(key => {
						Object.keys(form).forEach(dbKey => {
							// if(dbKey === "charging_standard"){
							// 	this.form['charging_rules'] = form[dbKey];
							// 	this.disabledObj['charging_rules_isDisabled'] = true;
							// };
							if(key === dbKey){
								this.disabledObj[key+'_isDisabled'] = true;
								this.form[key] = form[dbKey]
							}
							if(dbKey === "source_table"){
								this.form['source_table'] = form[dbKey];
							}
							if(dbKey === "source_id"){
								this.form['source_id'] = form[dbKey];
							}
							if(dbKey === "source_user_id"){
								this.form['source_user_id'] = form[dbKey];
							}
						})
					})
				}
																												        if (this.form["feedback_date"] && this.form["feedback_date"].indexOf("-")===-1){
          this.form["feedback_date"] = this.$toTime(parseInt(this.form["feedback_date"]),"yyyy-MM-dd")
        }
					$.db.del("form");
				return param;
			},

			/**
			 * 获取对象之后
			 * @param {Object} json
			 * @param {Object} func
			 */
			get_obj_after(json, func){

																																																																							if(json.result.obj["feedback_date"]=="0000-00-00"){
				  json.result.obj["feedback_date"] = null;
				}
				if(parseInt(json.result.obj["feedback_date"]) > 9999){
					json.result.obj["feedback_date"] = this.$toTime(parseInt(json.result.obj["feedback_date"]),"yyyy-MM-dd")
				}
				

			},

																																																																																																								async submit(param, func){
				if (!param) {
					param = this.form;
				}
								var pm = this.events("submit_before", Object.assign({}, param)) || param;
				var msg = await this.events("submit_check", pm);
				var ret;
				if (msg) {
					this.$toast(msg, 'danger');
				} else {
																																																																																																										ret = this.events("submit_main", pm, func);
				}
				return ret;
			},
			/**
			 * 提交前验证事件
			 * @param {Object} 请求参数
			 * @return {String} 验证成功返回null, 失败返回错误提示
			 */
						submit_check(param) {
																																																																																																														if (!param.student_name){
					return "学生姓名不能为空";
				}
																	if (!param.student_gender){
					return "学生性别不能为空";
				}
																	if (!param.mobile_phone_number){
					return "手机号码不能为空";
				}
																	if (!param.feedback_content){
					return "反馈内容不能为空";
				}
																	if (!param.feedback_date){
					return "反馈日期不能为空";
				}
																return null;
			},

			is_view(){
				// var bl = this.user_group == "管理员";
				var bl = false;

				if(!bl){
					bl = this.$check_action('/course_feedback/table','add');
					console.log(bl ? "你有表格添加权限视作有添加权限" : "你没有表格添加权限");
				}
				if(!bl){
					bl = this.$check_action('/course_feedback/table','set');
					console.log(bl ? "你有表格添加权限视作有修改权限" : "你没有表格修改权限");
				}
				if(!bl){
					bl = this.$check_action('/course_feedback/view','add');
					console.log(bl ? "你有视图添加权限视作有添加权限" : "你没有视图添加权限");
				}
				if(!bl){
					bl = this.$check_action('/course_feedback/view','set');
					console.log(bl ? "你有视图修改权限视作有修改权限" : "你没有视图修改权限");
				}
				if(!bl){
					bl = this.$check_action('/course_feedback/view','get');
					console.log(bl ? "你有视图查询权限视作有查询权限" : "你没有视图查询权限");
				}

				console.log(bl ? "具有当前页面的查看权，请注意这不代表你有字段的查看权" : "无权查看当前页，请注意即便有字段查询权限没有页面查询权限也不行");

				return bl;
			},
			/**
			 * 上传文件
			 * @param {Object} param
			 */
			uploadimg(param) {
				this.uploadFile(param.file, "avatar");
			},

		},
		created() {
															this.get_list_user_course_teacher();
												this.get_list_user_student_users();
															},
	}
</script>

<style>
	.avatar-uploader .el-upload {
		border: 1px dashed #d9d9d9;
		border-radius: 6px;
		cursor: pointer;
		position: relative;
		overflow: hidden;
	}

	.avatar-uploader .el-upload:hover {
		border-color: #409EFF;
	}

	.avatar-uploader-icon {
		font-size: 28px;
		color: #8c939d;
		width: 178px;
		height: 178px;
		line-height: 178px;
		text-align: center;
	}

	.avatar {
		width: 178px;
		height: 178px;
		display: block;
	}
	
	.img_multiple{
		overflow: hidden;
	}
	.img_multiple .img_block{
		float: left;
		margin-right: 5px;
		margin-bottom: 5px;
		position: relative;
	}
	.img_multiple .img_block img{
		height: 100px;
		width: auto;
	}
	.img_multiple .img_del{
		position: absolute;
		top: 5px;
		right: 5px;
		width: 20px;
		height: 20px;
		background: #0000008a;
		color: #fff;
		line-height: 20px;
		text-align: center;
		border-radius: 100%;
		cursor: pointer;
	}




</style>
