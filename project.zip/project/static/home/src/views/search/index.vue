<template>
  <div class="page_search search_index">
	<div class="warp">
	  <div class="container">
		<div class="row">
		  <div class="col-12">
			<div class="card_result_search">
			  <div class="title">搜索结果</div>

				<!-- 文章搜索结果 -->
			  <list_result_search
				:list="result_article"
				title="资讯信息"
				source_table="article"
			  ></list_result_search>


						  <list_result_search
				v-if="$check_action('/teacher_user/list', 'get')"
				:list="result_teacher_user_teacher_id"
				title="教师用户教师工号"
				source_table="teacher_user"
			  ></list_result_search>
								  <list_result_search
				v-if="$check_action('/teacher_user/list', 'get')"
				:list="result_teacher_user_teachers_name"
				title="教师用户教师姓名"
				source_table="teacher_user"
			  ></list_result_search>
												  <list_result_search
				v-if="$check_action('/student_users/list', 'get')"
				:list="result_student_users_student_name"
				title="学生用户学生姓名"
				source_table="student_users"
			  ></list_result_search>
											  <list_result_search
				v-if="$check_action('/student_users/list', 'get')"
				:list="result_student_users_mobile_phone_number"
				title="学生用户手机号码"
				source_table="student_users"
			  ></list_result_search>
												  <list_result_search
				v-if="$check_action('/course_information/list', 'get')"
				:list="result_course_information_course_name"
				title="课程信息课程名称"
				source_table="course_information"
			  ></list_result_search>
								  <list_result_search
				v-if="$check_action('/course_information/list', 'get')"
				:list="result_course_information_course_type"
				title="课程信息课程类型"
				source_table="course_information"
			  ></list_result_search>
														  <list_result_search
				v-if="$check_action('/course_information/list', 'get')"
				:list="result_course_information_class_name"
				title="课程信息班级名称"
				source_table="course_information"
			  ></list_result_search>
																					  <list_result_search
				v-if="$check_action('/class_information/list', 'get')"
				:list="result_class_information_class_name"
				title="班级信息班级名称"
				source_table="class_information"
			  ></list_result_search>
												  <list_result_search
				v-if="$check_action('/course_type/list', 'get')"
				:list="result_course_type_course_type"
				title="课程类型课程类型"
				source_table="course_type"
			  ></list_result_search>
															  <list_result_search
				v-if="$check_action('/application_for_course_selection/list', 'get')"
				:list="result_application_for_course_selection_course_name"
				title="选课申请课程名称"
				source_table="application_for_course_selection"
			  ></list_result_search>
														  <list_result_search
				v-if="$check_action('/application_for_course_selection/list', 'get')"
				:list="result_application_for_course_selection_class_name"
				title="选课申请班级名称"
				source_table="application_for_course_selection"
			  ></list_result_search>
																																				  <list_result_search
				v-if="$check_action('/course_selection_information/list', 'get')"
				:list="result_course_selection_information_course_name"
				title="选课信息课程名称"
				source_table="course_selection_information"
			  ></list_result_search>
														  <list_result_search
				v-if="$check_action('/course_selection_information/list', 'get')"
				:list="result_course_selection_information_class_name"
				title="选课信息班级名称"
				source_table="course_selection_information"
			  ></list_result_search>
																				  <list_result_search
				v-if="$check_action('/course_selection_information/list', 'get')"
				:list="result_course_selection_information_student_name"
				title="选课信息学生姓名"
				source_table="course_selection_information"
			  ></list_result_search>
																					  <list_result_search
				v-if="$check_action('/question_information/list', 'get')"
				:list="result_question_information_course_name"
				title="提问信息课程名称"
				source_table="question_information"
			  ></list_result_search>
														  <list_result_search
				v-if="$check_action('/question_information/list', 'get')"
				:list="result_question_information_class_name"
				title="提问信息班级名称"
				source_table="question_information"
			  ></list_result_search>
																																				  <list_result_search
				v-if="$check_action('/answer_information/list', 'get')"
				:list="result_answer_information_course_name"
				title="回答信息课程名称"
				source_table="answer_information"
			  ></list_result_search>
														  <list_result_search
				v-if="$check_action('/answer_information/list', 'get')"
				:list="result_answer_information_class_name"
				title="回答信息班级名称"
				source_table="answer_information"
			  ></list_result_search>
																				  <list_result_search
				v-if="$check_action('/answer_information/list', 'get')"
				:list="result_answer_information_student_name"
				title="回答信息学生姓名"
				source_table="answer_information"
			  ></list_result_search>
											  <list_result_search
				v-if="$check_action('/answer_information/list', 'get')"
				:list="result_answer_information_mobile_phone_number"
				title="回答信息手机号码"
				source_table="answer_information"
			  ></list_result_search>
																		  <list_result_search
				v-if="$check_action('/course_feedback/list', 'get')"
				:list="result_course_feedback_course_name"
				title="课程反馈课程名称"
				source_table="course_feedback"
			  ></list_result_search>
														  <list_result_search
				v-if="$check_action('/course_feedback/list', 'get')"
				:list="result_course_feedback_class_name"
				title="课程反馈班级名称"
				source_table="course_feedback"
			  ></list_result_search>
																																  <list_result_search
				v-if="$check_action('/course_feedback/list', 'get')"
				:list="result_course_feedback_feedback_date"
				title="课程反馈反馈日期"
				source_table="course_feedback"
			  ></list_result_search>
									  <list_result_search
				v-if="$check_action('/course_work/list', 'get')"
				:list="result_course_work_job_number"
				title="课程作业作业编号"
				source_table="course_work"
			  ></list_result_search>
																	  <list_result_search
				v-if="$check_action('/course_work/list', 'get')"
				:list="result_course_work_class_name"
				title="课程作业班级名称"
				source_table="course_work"
			  ></list_result_search>
																																	  <list_result_search
				v-if="$check_action('/finish_the_job/list', 'get')"
				:list="result_finish_the_job_job_number"
				title="完成作业作业编号"
				source_table="finish_the_job"
			  ></list_result_search>
																	  <list_result_search
				v-if="$check_action('/finish_the_job/list', 'get')"
				:list="result_finish_the_job_class_name"
				title="完成作业班级名称"
				source_table="finish_the_job"
			  ></list_result_search>
																																	  <list_result_search
				v-if="$check_action('/homework_correction/list', 'get')"
				:list="result_homework_correction_job_number"
				title="作业批改作业编号"
				source_table="homework_correction"
			  ></list_result_search>
																	  <list_result_search
				v-if="$check_action('/homework_correction/list', 'get')"
				:list="result_homework_correction_class_name"
				title="作业批改班级名称"
				source_table="homework_correction"
			  ></list_result_search>
																																				  <list_result_search
				v-if="$check_action('/assessment_record/list', 'get')"
				:list="result_assessment_record_course_name"
				title="评估记录课程名称"
				source_table="assessment_record"
			  ></list_result_search>
														  <list_result_search
				v-if="$check_action('/assessment_record/list', 'get')"
				:list="result_assessment_record_class_name"
				title="评估记录班级名称"
				source_table="assessment_record"
			  ></list_result_search>
																																  <list_result_search
				v-if="$check_action('/assessment_record/list', 'get')"
				:list="result_assessment_record_assessment_date"
				title="评估记录评估日期"
				source_table="assessment_record"
			  ></list_result_search>
												  <list_result_search
				v-if="$check_action('/progress_records/list', 'get')"
				:list="result_progress_records_course_name"
				title="进度记录课程名称"
				source_table="progress_records"
			  ></list_result_search>
														  <list_result_search
				v-if="$check_action('/progress_records/list', 'get')"
				:list="result_progress_records_class_name"
				title="进度记录班级名称"
				source_table="progress_records"
			  ></list_result_search>
																																  <list_result_search
				v-if="$check_action('/progress_records/list', 'get')"
				:list="result_progress_records_record_date"
				title="进度记录记录日期"
				source_table="progress_records"
			  ></list_result_search>
									  <list_result_search
				v-if="$check_action('/information/list', 'get')"
				:list="result_information_data_name"
				title="资料信息资料名称"
				source_table="information"
			  ></list_result_search>
								  <list_result_search
				v-if="$check_action('/information/list', 'get')"
				:list="result_information_data_type"
				title="资料信息资料类型"
				source_table="information"
			  ></list_result_search>
																								  <list_result_search
				v-if="$check_action('/data_type/list', 'get')"
				:list="result_data_type_data_type"
				title="资料类型资料类型"
				source_table="data_type"
			  ></list_result_search>
												  <list_result_search
				v-if="$check_action('/oral_recording/list', 'get')"
				:list="result_oral_recording_course_name"
				title="口语录音课程名称"
				source_table="oral_recording"
			  ></list_result_search>
														  <list_result_search
				v-if="$check_action('/oral_recording/list', 'get')"
				:list="result_oral_recording_class_name"
				title="口语录音班级名称"
				source_table="oral_recording"
			  ></list_result_search>
																				  <list_result_search
				v-if="$check_action('/oral_recording/list', 'get')"
				:list="result_oral_recording_student_name"
				title="口语录音学生姓名"
				source_table="oral_recording"
			  ></list_result_search>
															</div>
		  </div>
		</div>
	  </div>
	</div>
  </div>
</template>

<script>
import mixin from "../../mixins/page.js";
import list_result_search from "../../components/diy/list_result_search.vue";

export default {
  mixins: [mixin],
  data() {
	return {
	  "query": {
		word: "",
	  },
	  "result_article": [],
						"result_teacher_user_teacher_id":[],
								"result_teacher_user_teachers_name":[],
												"result_student_users_student_name":[],
											"result_student_users_mobile_phone_number":[],
												"result_course_information_course_name":[],
								"result_course_information_course_type":[],
														"result_course_information_class_name":[],
																					"result_class_information_class_name":[],
												"result_course_type_course_type":[],
															"result_application_for_course_selection_course_name":[],
														"result_application_for_course_selection_class_name":[],
																																				"result_course_selection_information_course_name":[],
														"result_course_selection_information_class_name":[],
																				"result_course_selection_information_student_name":[],
																					"result_question_information_course_name":[],
														"result_question_information_class_name":[],
																																				"result_answer_information_course_name":[],
														"result_answer_information_class_name":[],
																				"result_answer_information_student_name":[],
											"result_answer_information_mobile_phone_number":[],
																		"result_course_feedback_course_name":[],
														"result_course_feedback_class_name":[],
																																"result_course_feedback_feedback_date":[],
									"result_course_work_job_number":[],
																	"result_course_work_class_name":[],
																																	"result_finish_the_job_job_number":[],
																	"result_finish_the_job_class_name":[],
																																	"result_homework_correction_job_number":[],
																	"result_homework_correction_class_name":[],
																																				"result_assessment_record_course_name":[],
														"result_assessment_record_class_name":[],
																																"result_assessment_record_assessment_date":[],
												"result_progress_records_course_name":[],
														"result_progress_records_class_name":[],
																																"result_progress_records_record_date":[],
									"result_information_data_name":[],
								"result_information_data_type":[],
																								"result_data_type_data_type":[],
												"result_oral_recording_course_name":[],
														"result_oral_recording_class_name":[],
																				"result_oral_recording_student_name":[],
													};
  },
  methods: {
	/**
	 * 获取文章
	 */
	get_article() {
	  this.$get("~/api/article/get_list?like=0", { page: 1, size: 10, title: this.query.word }, (json) => {
		if (json.result) {
		  this.result_article = json.result.list;
		}
	  });
	},

				/**
	 * 获取teacher_id
	 */
	get_teacher_user_teacher_id(){
		let url = "~/api/teacher_user/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "teacher_id": this.query.word }, (json) => {
		  if (json.result) {
			var result_teacher_user_teacher_id = json.result.list;
			result_teacher_user_teacher_id.map(o => o.title = o['teacher_id'])
	  			this.result_teacher_user_teacher_id = result_teacher_user_teacher_id
		 	}
		});
	},
						/**
	 * 获取teachers_name
	 */
	get_teacher_user_teachers_name(){
		let url = "~/api/teacher_user/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "teachers_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_teacher_user_teachers_name = json.result.list;
			result_teacher_user_teachers_name.map(o => o.title = o['teachers_name'])
	  			this.result_teacher_user_teachers_name = result_teacher_user_teachers_name
		 	}
		});
	},
										/**
	 * 获取student_name
	 */
	get_student_users_student_name(){
		let url = "~/api/student_users/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "student_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_student_users_student_name = json.result.list;
			result_student_users_student_name.map(o => o.title = o['student_name'])
	  			this.result_student_users_student_name = result_student_users_student_name
		 	}
		});
	},
									/**
	 * 获取mobile_phone_number
	 */
	get_student_users_mobile_phone_number(){
		let url = "~/api/student_users/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "mobile_phone_number": this.query.word }, (json) => {
		  if (json.result) {
			var result_student_users_mobile_phone_number = json.result.list;
			result_student_users_mobile_phone_number.map(o => o.title = o['mobile_phone_number'])
	  			this.result_student_users_mobile_phone_number = result_student_users_mobile_phone_number
		 	}
		});
	},
										/**
	 * 获取course_name
	 */
	get_course_information_course_name(){
		let url = "~/api/course_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "course_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_course_information_course_name = json.result.list;
			result_course_information_course_name.map(o => o.title = o['course_name'])
	  			this.result_course_information_course_name = result_course_information_course_name
		 	}
		});
	},
						/**
	 * 获取course_type
	 */
	get_course_information_course_type(){
		let url = "~/api/course_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "course_type": this.query.word }, (json) => {
		  if (json.result) {
			var result_course_information_course_type = json.result.list;
			result_course_information_course_type.map(o => o.title = o['course_type'])
	  			this.result_course_information_course_type = result_course_information_course_type
		 	}
		});
	},
												/**
	 * 获取class_name
	 */
	get_course_information_class_name(){
		let url = "~/api/course_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_course_information_class_name = json.result.list;
			result_course_information_class_name.map(o => o.title = o['class_name'])
	  			this.result_course_information_class_name = result_course_information_class_name
		 	}
		});
	},
																			/**
	 * 获取class_name
	 */
	get_class_information_class_name(){
		let url = "~/api/class_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_class_information_class_name = json.result.list;
			result_class_information_class_name.map(o => o.title = o['class_name'])
	  			this.result_class_information_class_name = result_class_information_class_name
		 	}
		});
	},
										/**
	 * 获取course_type
	 */
	get_course_type_course_type(){
		let url = "~/api/course_type/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "course_type": this.query.word }, (json) => {
		  if (json.result) {
			var result_course_type_course_type = json.result.list;
			result_course_type_course_type.map(o => o.title = o['course_type'])
	  			this.result_course_type_course_type = result_course_type_course_type
		 	}
		});
	},
													/**
	 * 获取course_name
	 */
	get_application_for_course_selection_course_name(){
		let url = "~/api/application_for_course_selection/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "course_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_application_for_course_selection_course_name = json.result.list;
			result_application_for_course_selection_course_name.map(o => o.title = o['course_name'])
	  			this.result_application_for_course_selection_course_name = result_application_for_course_selection_course_name
		 	}
		});
	},
												/**
	 * 获取class_name
	 */
	get_application_for_course_selection_class_name(){
		let url = "~/api/application_for_course_selection/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_application_for_course_selection_class_name = json.result.list;
			result_application_for_course_selection_class_name.map(o => o.title = o['class_name'])
	  			this.result_application_for_course_selection_class_name = result_application_for_course_selection_class_name
		 	}
		});
	},
																																		/**
	 * 获取course_name
	 */
	get_course_selection_information_course_name(){
		let url = "~/api/course_selection_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "course_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_course_selection_information_course_name = json.result.list;
			result_course_selection_information_course_name.map(o => o.title = o['course_name'])
	  			this.result_course_selection_information_course_name = result_course_selection_information_course_name
		 	}
		});
	},
												/**
	 * 获取class_name
	 */
	get_course_selection_information_class_name(){
		let url = "~/api/course_selection_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_course_selection_information_class_name = json.result.list;
			result_course_selection_information_class_name.map(o => o.title = o['class_name'])
	  			this.result_course_selection_information_class_name = result_course_selection_information_class_name
		 	}
		});
	},
																		/**
	 * 获取student_name
	 */
	get_course_selection_information_student_name(){
		let url = "~/api/course_selection_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "student_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_course_selection_information_student_name = json.result.list;
			result_course_selection_information_student_name.map(o => o.title = o['student_name'])
	  			this.result_course_selection_information_student_name = result_course_selection_information_student_name
		 	}
		});
	},
																			/**
	 * 获取course_name
	 */
	get_question_information_course_name(){
		let url = "~/api/question_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "course_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_question_information_course_name = json.result.list;
			result_question_information_course_name.map(o => o.title = o['course_name'])
	  			this.result_question_information_course_name = result_question_information_course_name
		 	}
		});
	},
												/**
	 * 获取class_name
	 */
	get_question_information_class_name(){
		let url = "~/api/question_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_question_information_class_name = json.result.list;
			result_question_information_class_name.map(o => o.title = o['class_name'])
	  			this.result_question_information_class_name = result_question_information_class_name
		 	}
		});
	},
																																		/**
	 * 获取course_name
	 */
	get_answer_information_course_name(){
		let url = "~/api/answer_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "course_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_answer_information_course_name = json.result.list;
			result_answer_information_course_name.map(o => o.title = o['course_name'])
	  			this.result_answer_information_course_name = result_answer_information_course_name
		 	}
		});
	},
												/**
	 * 获取class_name
	 */
	get_answer_information_class_name(){
		let url = "~/api/answer_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_answer_information_class_name = json.result.list;
			result_answer_information_class_name.map(o => o.title = o['class_name'])
	  			this.result_answer_information_class_name = result_answer_information_class_name
		 	}
		});
	},
																		/**
	 * 获取student_name
	 */
	get_answer_information_student_name(){
		let url = "~/api/answer_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "student_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_answer_information_student_name = json.result.list;
			result_answer_information_student_name.map(o => o.title = o['student_name'])
	  			this.result_answer_information_student_name = result_answer_information_student_name
		 	}
		});
	},
									/**
	 * 获取mobile_phone_number
	 */
	get_answer_information_mobile_phone_number(){
		let url = "~/api/answer_information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "mobile_phone_number": this.query.word }, (json) => {
		  if (json.result) {
			var result_answer_information_mobile_phone_number = json.result.list;
			result_answer_information_mobile_phone_number.map(o => o.title = o['mobile_phone_number'])
	  			this.result_answer_information_mobile_phone_number = result_answer_information_mobile_phone_number
		 	}
		});
	},
																/**
	 * 获取course_name
	 */
	get_course_feedback_course_name(){
		let url = "~/api/course_feedback/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "course_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_course_feedback_course_name = json.result.list;
			result_course_feedback_course_name.map(o => o.title = o['course_name'])
	  			this.result_course_feedback_course_name = result_course_feedback_course_name
		 	}
		});
	},
												/**
	 * 获取class_name
	 */
	get_course_feedback_class_name(){
		let url = "~/api/course_feedback/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_course_feedback_class_name = json.result.list;
			result_course_feedback_class_name.map(o => o.title = o['class_name'])
	  			this.result_course_feedback_class_name = result_course_feedback_class_name
		 	}
		});
	},
																														/**
	 * 获取feedback_date
	 */
	get_course_feedback_feedback_date(){
		let url = "~/api/course_feedback/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "feedback_date": this.query.word }, (json) => {
		  if (json.result) {
			var result_course_feedback_feedback_date = json.result.list;
			result_course_feedback_feedback_date.map(o => o.title = o['feedback_date'])
	  			this.result_course_feedback_feedback_date = result_course_feedback_feedback_date
		 	}
		});
	},
							/**
	 * 获取job_number
	 */
	get_course_work_job_number(){
		let url = "~/api/course_work/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "job_number": this.query.word }, (json) => {
		  if (json.result) {
			var result_course_work_job_number = json.result.list;
			result_course_work_job_number.map(o => o.title = o['job_number'])
	  			this.result_course_work_job_number = result_course_work_job_number
		 	}
		});
	},
															/**
	 * 获取class_name
	 */
	get_course_work_class_name(){
		let url = "~/api/course_work/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_course_work_class_name = json.result.list;
			result_course_work_class_name.map(o => o.title = o['class_name'])
	  			this.result_course_work_class_name = result_course_work_class_name
		 	}
		});
	},
																															/**
	 * 获取job_number
	 */
	get_finish_the_job_job_number(){
		let url = "~/api/finish_the_job/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "job_number": this.query.word }, (json) => {
		  if (json.result) {
			var result_finish_the_job_job_number = json.result.list;
			result_finish_the_job_job_number.map(o => o.title = o['job_number'])
	  			this.result_finish_the_job_job_number = result_finish_the_job_job_number
		 	}
		});
	},
															/**
	 * 获取class_name
	 */
	get_finish_the_job_class_name(){
		let url = "~/api/finish_the_job/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_finish_the_job_class_name = json.result.list;
			result_finish_the_job_class_name.map(o => o.title = o['class_name'])
	  			this.result_finish_the_job_class_name = result_finish_the_job_class_name
		 	}
		});
	},
																															/**
	 * 获取job_number
	 */
	get_homework_correction_job_number(){
		let url = "~/api/homework_correction/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "job_number": this.query.word }, (json) => {
		  if (json.result) {
			var result_homework_correction_job_number = json.result.list;
			result_homework_correction_job_number.map(o => o.title = o['job_number'])
	  			this.result_homework_correction_job_number = result_homework_correction_job_number
		 	}
		});
	},
															/**
	 * 获取class_name
	 */
	get_homework_correction_class_name(){
		let url = "~/api/homework_correction/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_homework_correction_class_name = json.result.list;
			result_homework_correction_class_name.map(o => o.title = o['class_name'])
	  			this.result_homework_correction_class_name = result_homework_correction_class_name
		 	}
		});
	},
																																		/**
	 * 获取course_name
	 */
	get_assessment_record_course_name(){
		let url = "~/api/assessment_record/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "course_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_assessment_record_course_name = json.result.list;
			result_assessment_record_course_name.map(o => o.title = o['course_name'])
	  			this.result_assessment_record_course_name = result_assessment_record_course_name
		 	}
		});
	},
												/**
	 * 获取class_name
	 */
	get_assessment_record_class_name(){
		let url = "~/api/assessment_record/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_assessment_record_class_name = json.result.list;
			result_assessment_record_class_name.map(o => o.title = o['class_name'])
	  			this.result_assessment_record_class_name = result_assessment_record_class_name
		 	}
		});
	},
																														/**
	 * 获取assessment_date
	 */
	get_assessment_record_assessment_date(){
		let url = "~/api/assessment_record/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "assessment_date": this.query.word }, (json) => {
		  if (json.result) {
			var result_assessment_record_assessment_date = json.result.list;
			result_assessment_record_assessment_date.map(o => o.title = o['assessment_date'])
	  			this.result_assessment_record_assessment_date = result_assessment_record_assessment_date
		 	}
		});
	},
										/**
	 * 获取course_name
	 */
	get_progress_records_course_name(){
		let url = "~/api/progress_records/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "course_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_progress_records_course_name = json.result.list;
			result_progress_records_course_name.map(o => o.title = o['course_name'])
	  			this.result_progress_records_course_name = result_progress_records_course_name
		 	}
		});
	},
												/**
	 * 获取class_name
	 */
	get_progress_records_class_name(){
		let url = "~/api/progress_records/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_progress_records_class_name = json.result.list;
			result_progress_records_class_name.map(o => o.title = o['class_name'])
	  			this.result_progress_records_class_name = result_progress_records_class_name
		 	}
		});
	},
																														/**
	 * 获取record_date
	 */
	get_progress_records_record_date(){
		let url = "~/api/progress_records/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "record_date": this.query.word }, (json) => {
		  if (json.result) {
			var result_progress_records_record_date = json.result.list;
			result_progress_records_record_date.map(o => o.title = o['record_date'])
	  			this.result_progress_records_record_date = result_progress_records_record_date
		 	}
		});
	},
							/**
	 * 获取data_name
	 */
	get_information_data_name(){
		let url = "~/api/information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "data_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_information_data_name = json.result.list;
			result_information_data_name.map(o => o.title = o['data_name'])
	  			this.result_information_data_name = result_information_data_name
		 	}
		});
	},
						/**
	 * 获取data_type
	 */
	get_information_data_type(){
		let url = "~/api/information/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "data_type": this.query.word }, (json) => {
		  if (json.result) {
			var result_information_data_type = json.result.list;
			result_information_data_type.map(o => o.title = o['data_type'])
	  			this.result_information_data_type = result_information_data_type
		 	}
		});
	},
																						/**
	 * 获取data_type
	 */
	get_data_type_data_type(){
		let url = "~/api/data_type/get_list?like=0";
				this.$get(url, { page: 1, size: 10, "data_type": this.query.word }, (json) => {
		  if (json.result) {
			var result_data_type_data_type = json.result.list;
			result_data_type_data_type.map(o => o.title = o['data_type'])
	  			this.result_data_type_data_type = result_data_type_data_type
		 	}
		});
	},
										/**
	 * 获取course_name
	 */
	get_oral_recording_course_name(){
		let url = "~/api/oral_recording/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "course_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_oral_recording_course_name = json.result.list;
			result_oral_recording_course_name.map(o => o.title = o['course_name'])
	  			this.result_oral_recording_course_name = result_oral_recording_course_name
		 	}
		});
	},
												/**
	 * 获取class_name
	 */
	get_oral_recording_class_name(){
		let url = "~/api/oral_recording/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "class_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_oral_recording_class_name = json.result.list;
			result_oral_recording_class_name.map(o => o.title = o['class_name'])
	  			this.result_oral_recording_class_name = result_oral_recording_class_name
		 	}
		});
	},
																		/**
	 * 获取student_name
	 */
	get_oral_recording_student_name(){
		let url = "~/api/oral_recording/get_list?like=0";
				url = url+"&examine_state=已通过";
				this.$get(url, { page: 1, size: 10, "student_name": this.query.word }, (json) => {
		  if (json.result) {
			var result_oral_recording_student_name = json.result.list;
			result_oral_recording_student_name.map(o => o.title = o['student_name'])
	  			this.result_oral_recording_student_name = result_oral_recording_student_name
		 	}
		});
	},
												
  },
  components: { list_result_search },
	created(){
    this.query.word = this.$route.query.word || "";
  },
  mounted() {
	this.get_article();
					this.get_teacher_user_teacher_id();
							this.get_teacher_user_teachers_name();
											this.get_student_users_student_name();
										this.get_student_users_mobile_phone_number();
											this.get_course_information_course_name();
							this.get_course_information_course_type();
													this.get_course_information_class_name();
																				this.get_class_information_class_name();
											this.get_course_type_course_type();
														this.get_application_for_course_selection_course_name();
													this.get_application_for_course_selection_class_name();
																																			this.get_course_selection_information_course_name();
													this.get_course_selection_information_class_name();
																			this.get_course_selection_information_student_name();
																				this.get_question_information_course_name();
													this.get_question_information_class_name();
																																			this.get_answer_information_course_name();
													this.get_answer_information_class_name();
																			this.get_answer_information_student_name();
										this.get_answer_information_mobile_phone_number();
																	this.get_course_feedback_course_name();
													this.get_course_feedback_class_name();
																															this.get_course_feedback_feedback_date();
								this.get_course_work_job_number();
																this.get_course_work_class_name();
																																this.get_finish_the_job_job_number();
																this.get_finish_the_job_class_name();
																																this.get_homework_correction_job_number();
																this.get_homework_correction_class_name();
																																			this.get_assessment_record_course_name();
													this.get_assessment_record_class_name();
																															this.get_assessment_record_assessment_date();
											this.get_progress_records_course_name();
													this.get_progress_records_class_name();
																															this.get_progress_records_record_date();
								this.get_information_data_name();
							this.get_information_data_type();
																							this.get_data_type_data_type();
											this.get_oral_recording_course_name();
													this.get_oral_recording_class_name();
																			this.get_oral_recording_student_name();
												  },
  watch: {
	$route() {
	  $.push(this.query, this.$route.query);
	  this.get_article();
				  this.get_teacher_user_teacher_id();
						  this.get_teacher_user_teachers_name();
										  this.get_student_users_student_name();
									  this.get_student_users_mobile_phone_number();
										  this.get_course_information_course_name();
						  this.get_course_information_course_type();
												  this.get_course_information_class_name();
																			  this.get_class_information_class_name();
										  this.get_course_type_course_type();
													  this.get_application_for_course_selection_course_name();
												  this.get_application_for_course_selection_class_name();
																																		  this.get_course_selection_information_course_name();
												  this.get_course_selection_information_class_name();
																		  this.get_course_selection_information_student_name();
																			  this.get_question_information_course_name();
												  this.get_question_information_class_name();
																																		  this.get_answer_information_course_name();
												  this.get_answer_information_class_name();
																		  this.get_answer_information_student_name();
									  this.get_answer_information_mobile_phone_number();
																  this.get_course_feedback_course_name();
												  this.get_course_feedback_class_name();
																														  this.get_course_feedback_feedback_date();
							  this.get_course_work_job_number();
															  this.get_course_work_class_name();
																															  this.get_finish_the_job_job_number();
															  this.get_finish_the_job_class_name();
																															  this.get_homework_correction_job_number();
															  this.get_homework_correction_class_name();
																																		  this.get_assessment_record_course_name();
												  this.get_assessment_record_class_name();
																														  this.get_assessment_record_assessment_date();
										  this.get_progress_records_course_name();
												  this.get_progress_records_class_name();
																														  this.get_progress_records_record_date();
							  this.get_information_data_name();
						  this.get_information_data_type();
																						  this.get_data_type_data_type();
										  this.get_oral_recording_course_name();
												  this.get_oral_recording_class_name();
																		  this.get_oral_recording_student_name();
													},
  },
};
</script>

<style scoped>
.card_search {
  text-align: center;
}
.card_result_search>.title {
  text-align: center;
  padding: 10px 0;
}
</style>
