<template>
	<div class="diy_edit page_application_for_course_selection" id="application_for_course_selection_edit">
		<div class='warp'>
			<div class='container'>
				<div class='row diy_edit_content_box'>
						<div v-if="$check_field('set','enrollment_number') || $check_field('add','enrollment_number') || $check_field('get','enrollment_number')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								报名编号:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_enrollment_number" v-model="form['enrollment_number']" placeholder="请输入报名编号" v-if="(form['enrollment_number'] && $check_field('set','enrollment_number')) || (!form['enrollment_number'] && $check_field('add','enrollment_number'))" :disabled="true"/>
							<span v-else-if="$check_field('get','enrollment_number')">{{ form['enrollment_number'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','course_number') || $check_field('add','course_number') || $check_field('get','course_number')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								课程编号:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_course_number" v-model="form['course_number']" placeholder="请输入课程编号" v-if="(form['course_number'] && $check_field('set','course_number')) || (!form['course_number'] && $check_field('add','course_number'))"  :disabled="disabledObj['course_number_isDisabled']"/>
							<span v-else-if="$check_field('get','course_number')">{{ form['course_number'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','course_name') || $check_field('add','course_name') || $check_field('get','course_name')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								课程名称:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_course_name" v-model="form['course_name']" placeholder="请输入课程名称" v-if="(form['course_name'] && $check_field('set','course_name')) || (!form['course_name'] && $check_field('add','course_name'))"  :disabled="disabledObj['course_name_isDisabled']"/>
							<span v-else-if="$check_field('get','course_name')">{{ form['course_name'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','course_type') || $check_field('add','course_type') || $check_field('get','course_type')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								课程类型:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_course_type" v-model="form['course_type']" placeholder="请输入课程类型" v-if="(form['course_type'] && $check_field('set','course_type')) || (!form['course_type'] && $check_field('add','course_type'))"  :disabled="disabledObj['course_type_isDisabled']"/>
							<span v-else-if="$check_field('get','course_type')">{{ form['course_type'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','course_duration') || $check_field('add','course_duration') || $check_field('get','course_duration')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								课程时间:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_course_duration" v-model="form['course_duration']" placeholder="请输入课程时间" v-if="(form['course_duration'] && $check_field('set','course_duration')) || (!form['course_duration'] && $check_field('add','course_duration'))"  :disabled="disabledObj['course_duration_isDisabled']"/>
							<span v-else-if="$check_field('get','course_duration')">{{ form['course_duration'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','class_name') || $check_field('add','class_name') || $check_field('get','class_name')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								班级名称:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_class_name" v-model="form['class_name']" placeholder="请输入班级名称" v-if="(form['class_name'] && $check_field('set','class_name')) || (!form['class_name'] && $check_field('add','class_name'))"  :disabled="disabledObj['class_name_isDisabled']"/>
							<span v-else-if="$check_field('get','class_name')">{{ form['class_name'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','course_teacher') || $check_field('add','course_teacher') || $check_field('get','course_teacher')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								课程教师:
							</span>
						</div>
						<div class="diy_field diy_down">
							<select id="form_course_teacher" :disabled="disabledObj['course_teacher_isDisabled']" v-model="form['course_teacher']" v-if="(form['course_teacher'] && $check_field('set','course_teacher')) || (!form['course_teacher'] && $check_field('add','course_teacher'))" >
								<option v-for="o in list_user_course_teacher" :value="o['user_id']">
									{{o['nickname'] + '-' + o['username']}}
								</option>
							</select>
							<span v-else-if="$check_field('get','course_teacher')">{{ get_user_info("course_teacher", form['course_teacher']) }}</span>
						</div>
					</div>
							<div v-if="$check_field('set','teacher_id') || $check_field('add','teacher_id') || $check_field('get','teacher_id')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								教师工号:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_teacher_id" v-model="form['teacher_id']" placeholder="请输入教师工号" v-if="(form['teacher_id'] && $check_field('set','teacher_id')) || (!form['teacher_id'] && $check_field('add','teacher_id'))"  :disabled="disabledObj['teacher_id_isDisabled']"/>
							<span v-else-if="$check_field('get','teacher_id')">{{ form['teacher_id'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','teachers_name') || $check_field('add','teachers_name') || $check_field('get','teachers_name')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								教师姓名:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_teachers_name" v-model="form['teachers_name']" placeholder="请输入教师姓名" v-if="(form['teachers_name'] && $check_field('set','teachers_name')) || (!form['teachers_name'] && $check_field('add','teachers_name'))"  :disabled="disabledObj['teachers_name_isDisabled']"/>
							<span v-else-if="$check_field('get','teachers_name')">{{ form['teachers_name'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','student_users') || $check_field('add','student_users') || $check_field('get','student_users')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								学生用户:
							</span>
						</div>
						<div class="diy_field diy_down">
							<select id="form_student_users" :disabled="disabledObj['student_users_isDisabled']" v-model="form['student_users']" v-if="(form['student_users'] && $check_field('set','student_users')) || (!form['student_users'] && $check_field('add','student_users'))" >
								<option v-for="o in list_user_student_users" :value="o['user_id']">
									{{o['nickname'] + '-' + o['username']}}
								</option>
							</select>
							<span v-else-if="$check_field('get','student_users')">{{ get_user_info("student_users", form['student_users']) }}</span>
						</div>
					</div>
							<div v-if="$check_field('set','student_name') || $check_field('add','student_name') || $check_field('get','student_name')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								学生姓名:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_student_name" v-model="form['student_name']" placeholder="请输入学生姓名" v-if="(form['student_name'] && $check_field('set','student_name')) || (!form['student_name'] && $check_field('add','student_name'))"  :disabled="disabledObj['student_name_isDisabled']"/>
							<span v-else-if="$check_field('get','student_name')">{{ form['student_name'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','student_gender') || $check_field('add','student_gender') || $check_field('get','student_gender')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								学生性别:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_student_gender" v-model="form['student_gender']" placeholder="请输入学生性别" v-if="(form['student_gender'] && $check_field('set','student_gender')) || (!form['student_gender'] && $check_field('add','student_gender'))"  :disabled="disabledObj['student_gender_isDisabled']"/>
							<span v-else-if="$check_field('get','student_gender')">{{ form['student_gender'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','mobile_phone_number') || $check_field('add','mobile_phone_number') || $check_field('get','mobile_phone_number')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								手机号码:
							</span>
						</div>
								<!-- 文本 -->
									<div class="diy_field diy_text">
							<input type="text" id="form_mobile_phone_number" v-model="form['mobile_phone_number']" placeholder="请输入手机号码" v-if="(form['mobile_phone_number'] && $check_field('set','mobile_phone_number')) || (!form['mobile_phone_number'] && $check_field('add','mobile_phone_number'))"  :disabled="disabledObj['mobile_phone_number_isDisabled']"/>
							<span v-else-if="$check_field('get','mobile_phone_number')">{{ form['mobile_phone_number'] }}</span>
						</div>
										</div>
							<div v-if="$check_field('set','registration_remarks') || $check_field('add','registration_remarks') || $check_field('get','registration_remarks')" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								报名备注:
							</span>
						</div>
								<!-- 多文本 -->
						<div class="diy_field diy_desc">
							<textarea id="form_registration_remarks" v-model="form['registration_remarks']" v-if="(form['registration_remarks'] && $check_field('set','registration_remarks')) || (!form['registration_remarks'] && $check_field('add','registration_remarks'))" :disabled="disabledObj['registration_remarks_isDisabled']" />
							<span v-else-if="$check_field('get','registration_remarks')">{{ form['registration_remarks'] }}</span>
						</div>
							</div>
	


					<div v-if="$check_examine()" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								审核状态:
							</span>
						</div>
						<div class="diy_field diy_select" v-if="$check_action('/application_for_course_selection/edit','examine')">
							<!--<span> {{ form['examine_state'] }} </span>-->
							<select v-model="form['examine_state']">
								<option value="未审核">
									未审核
								</option>
								<option value="已通过">
									已通过
								</option>
								<option value="未通过">
									未通过
								</option>
							</select>
						</div>
						<div class="diy_field diy_text" v-else>
							<span>
								{{ form['examine_state'] }}
							</span>
						</div>
					</div>
					<div v-if="$check_examine()" class="form-item col-12 col-md-6">
						<div class="diy_title">
							<span>
								审核回复:
							</span>
						</div>
						<div class="diy_field diy_desc" v-if="$check_action('/application_for_course_selection/edit','examine')">
							<textarea v-model="form['examine_reply']"></textarea>
						</div>
						<div class="diy_field diy_text" v-else>
							<span>
								{{ form['examine_reply'] }}
							</span>
						</div>
					</div>


				</div>
				<div class="diy_edit_submit_box row">
					<div class="col-12">
						<div class="btn_box">
							<button class="btn_submit" @click="submit()">提交</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import mixin from "@/mixins/page.js";
	export default {
		mixins: [mixin],
		components: {},
		data() {
			return {
				url_get_obj: "~/api/application_for_course_selection/get_obj?",
				url_add: "~/api/application_for_course_selection/add?",
				url_set: "~/api/application_for_course_selection/set?",

				// 登录权限
				oauth: {
					"signIn": true,
					"user_group": []
				},

				// 查询条件
				query: {
						"enrollment_number": "",
							"course_number": "",
							"course_name": "",
							"course_type": "",
							"course_duration": "",
							"class_name": "",
							"course_teacher": 0,
							"teacher_id": "",
							"teachers_name": "",
							"student_users": 0,
							"student_name": "",
							"student_gender": "",
							"mobile_phone_number": "",
							"registration_remarks": "",
						"application_for_course_selection_id": 0,
				},

				obj: {
						"enrollment_number": this.$get_stamp(), // 报名编号
							"course_number":  '', // 课程编号
							"course_name":  '', // 课程名称
							"course_type":  '', // 课程类型
							"course_duration":  '', // 课程时间
							"class_name":  '', // 班级名称
							"course_teacher": 0, // 课程教师
							"teacher_id":  '', // 教师工号
							"teachers_name":  '', // 教师姓名
							"student_users": 0, // 学生用户
							"student_name": null, // 学生姓名
							"student_gender": null, // 学生性别
							"mobile_phone_number": null, // 手机号码
							"registration_remarks":  '', // 报名备注
						"examine_state": "未审核",
					"examine_reply": "",
					"application_for_course_selection_id": 0,
				},

				// 表单字段
				form: {
						"enrollment_number": this.$get_stamp(), // 报名编号
							"course_number":  '', // 课程编号
							"course_name":  '', // 课程名称
							"course_type":  '', // 课程类型
							"course_duration":  '', // 课程时间
							"class_name":  '', // 班级名称
							"course_teacher": 0, // 课程教师
							"teacher_id":  '', // 教师工号
							"teachers_name":  '', // 教师姓名
							"student_users": 0, // 学生用户
							"student_name":  '', // 学生姓名
							"student_gender":  '', // 学生性别
							"mobile_phone_number":  '', // 手机号码
							"registration_remarks":  '', // 报名备注
						"examine_state": "未审核",
					"examine_reply": "",
					"application_for_course_selection_id": 0,
				},
				disabledObj:{
						"enrollment_number_isDisabled": false,
							"course_number_isDisabled": false,
							"course_name_isDisabled": false,
							"course_type_isDisabled": false,
							"course_duration_isDisabled": false,
							"class_name_isDisabled": false,
							"course_teacher_isDisabled": false,
							"teacher_id_isDisabled": false,
							"teachers_name_isDisabled": false,
							"student_users_isDisabled": false,
							"student_name_isDisabled": false,
							"student_gender_isDisabled": false,
							"mobile_phone_number_isDisabled": false,
							"registration_remarks_isDisabled": false,
					},

																								// 用户列表
				list_user_course_teacher: [],
														// 用户列表
				list_user_student_users: [],
														
				// ID字段
				field: "application_for_course_selection_id",

			}
		},
		methods: {
																																																																																																																						formatDateValue(value) {
		  const date = new Date(value);
		  return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}`;
		},
		async submit(param, func){
			if (!param) {
				param = this.form;
			}
						var pm = this.events("submit_before", Object.assign({}, param)) || param;
			var msg = await this.events("submit_check", pm);
			var ret;
			if (msg) {
				this.$toast(msg, 'danger');
			} else {
																																															ret = this.events("submit_main", pm, func);
			}
			return ret;
		},
		
      /**
       * 提交前验证事件
       * @param {Object} 请求参数
       * @return {String} 验证成功返回null, 失败返回错误提示
       */
            submit_check(param) {
      																																																					if (!param.student_name){
		  return "学生姓名不能为空";
		}
								if (!param.student_gender){
		  return "学生性别不能为空";
		}
								if (!param.mobile_phone_number){
		  return "手机号码不能为空";
		}
										        return null;
      },
			
				
				
				
				
				
						/**
			 * 获取教师用户用户列表
			 */
			async get_list_user_course_teacher() {
				var json = await this.$get("~/api/user/get_list?user_group=教师用户");
				if(json.result && json.result.list){
					this.list_user_course_teacher = json.result.list;
				}
				else if(json.error){
					console.error(json.error);
				}
			},
		
				
				
						/**
			 * 获取学生用户用户列表
			 */
			async get_list_user_student_users() {
				var json = await this.$get("~/api/user/get_list?user_group=学生用户");
				if(json.result && json.result.list){
					this.list_user_student_users = json.result.list;
				}
				else if(json.error){
					console.error(json.error);
				}
			},
					async get_user_session_student_users(){
				var _this = this;
				var json = await this.$get("~/api/user_group/get_obj?name=学生用户");
				if(json.result && json.result.obj){
					var source_table = json.result.obj.source_table;
					var user_id = _this.$store.state.user.user_id;
					if (user_id){
						var url = "~/api/"+source_table+"/get_obj?"
						this.$get(url, {"user_id":_this.$store.state.user.user_id}, function(res) {
							if (res.result && res.result.obj) {
								var arr = []
								for (let key in res.result.obj) {
									arr.push(key)
								}
								var arrForm = []
								for (let key in _this.form) {
									arrForm.push(key)
								}
								_this.form["student_users"] = user_id
								_this.disabledObj['student_users' + '_isDisabled'] = true
								for (var i=0;i<arr.length;i++){
                  if (arr[i]!=='examine_state' && arr[i]!=='examine_reply') {
                    for (var j = 0; j < arrForm.length; j++) {
                      if (arr[i] === arrForm[j]) {
                        if (arr[i] !== "student_users") {
                          _this.form[arrForm[j]] = res.result.obj[arr[i]]
                          _this.disabledObj[arrForm[j] + '_isDisabled'] = true
                          break;
                        }
                      }
                    }
                  }
								}
							}
						});
					}
				}
				else if(json.error){
					console.error(json.error);
				}
			},
	
				
				
				
				
		  		get_user_info(name,id){
				var obj = null;
              				  if (name == 'course_teacher'){
					  obj = this.list_user_course_teacher.getObj({"user_id":id});
				  }
        				  if (name == 'student_users'){
					  obj = this.list_user_student_users.getObj({"user_id":id});
				  }
          				var ret = "";
				if(obj){
				  ret = obj.nickname+"-"+obj.username;
				}
				return ret;
			},
			/**
			 * 修改文件
			 * @param { Object } files 上传文件对象
			 * @param { String } str 表单的属性名
			 */
			change_file(files, str) {
				var form = new FormData();
				form.append("file", files[0]);
				this.$post("~/api/application_for_course_selection/upload?", form, (res) => {
					if (res.result) {
						this.form[str] = res.result.url;
					} else if (res.error) {
						this.$toast(res.error.message);
					}
				});
			},
			
			/**
			 * 修改文件
			 * @param { Object } files 上传文件对象
			 * @param { String } str 表单的属性名
			 */
			change_file_multiple(files, str) {
				let _this = this;
				var form = new FormData();
				for (var i = 0; i < files.length; i++) {
					form.set("file", files[i]);
					_this.$post("~/api/application_for_course_selection/upload?", form, (res) => {
						if (res.result) {
							if (_this.form[str].length > 0) {
								_this.form[str].push(res.result.url);
							} else {
								_this.form[str] = [res.result.url];
							}
						} else if (res.error) {
							_this.$toast(res.error.message);
						}
					});
				}
			},

			/**
			 * 获取对象后获取缓存表单
			 * @param {Object} json
			 * @param {Object} func
			 */
			get_obj_before(param){
				var form = $.db.get("form");
				// if (form) {
        //   delete(form.examine_state)
        //   delete(form.examine_reply)
        //   this.obj = $.push(this.obj ,form);
				// 	this.form = $.push(this.form ,form);
				// }
				// var arr = []
				// for (let key in form) {
				// 	arr.push(key)
				// }
				// for (var i=0;i<arr.length;i++){
				// 	this.disabledObj[arr[i] + '_isDisabled'] = true
				// }
        if (form) {
          var arr = []
          for (let key in form) {
            arr.push(key)
          }
          var arrForm = []
          for (let key in this.form) {
            arrForm.push(key)
          }
          for (var i=0;i<arr.length;i++){
            if (arr[i]!=='examine_state' && arr[i]!=='examine_reply') {
              for (var j = 0; j < arrForm.length; j++) {
                if (arrForm[j] === arr[i]) {
                  this.form[arrForm[j]] = form[arr[i]]
                  this.obj[arrForm[j]] = form[arr[i]]
                  this.disabledObj[arrForm[j] + '_isDisabled'] = true
                  break;
                }
              }
			  if(arr[i] === "source_table"){
			  	this.form['source_table'] = form[arr[i]]
			  }
			  if(arr[i] === "source_id"){
			  	this.form['source_id'] = form[arr[i]]
			  }
			  if(arr[i] === "source_user_id"){
			  	this.form['source_user_id'] = form[arr[i]]
			  }
            }
          }
        }
																																										
        $.db.del("form");
				return param;
			},

			/**
			 * 获取对象后获取缓存表单
			 * @param {Object} json
			 * @param {Object} func
			 */
			get_obj_after(json ,func){
				// var form = $.db.get("form");
				// var obj = Object.assign({} ,form ,this.obj);
				// if (obj) {
        //   delete(obj.examine_state)
        //   delete(obj.examine_reply)
				// 	this.obj = $.push(this.obj ,obj);
				// }
				// if (form) {
        //   delete(form.examine_state)
        //   delete(form.examine_reply)
				// 	this.form = $.push(this.form ,form);
				// }

				if(func){
					func(json);
				}
			},

		},
		created() {
																								this.get_list_user_course_teacher();
												this.get_user_session_student_users();
					this.get_list_user_student_users();
															},
	}
</script>

<style>
	.diy_compute{
		line-height: 40px;
	}
	.diy_field.diy_img_multiple{
		margin: 0;
	}
	.diy_field.diy_img_multiple div{
		float: left;
		position: relative;
		margin: 0 10px 10px 0;
	}
	.diy_field.diy_img_multiple img{
		height: 100px;
		width: auto;
	}
	.diy_field.diy_img_multiple span{
		position: absolute;
		top: 5px;
		right: 5px;
		width: 20px;
		height: 20px;
		background: #0000008a;
		color: #fff;
		line-height: 20px;
		text-align: center;
		border-radius: 100%;
		cursor: pointer;
	}



</style>
