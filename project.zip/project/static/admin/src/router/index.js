import Vue from 'vue';
import VueRouter from 'vue-router';
import index from '../views/index.vue';
import login from '../views/login.vue';
import forgot from '../views/forgot.vue';
import register from '../views/register.vue';
Vue.use(VueRouter)

const routes = [
    // 主页
    {
        path: '/',
        name: 'index',
        component: index,
        meta: {
            index: 0,
            title: '首页'
        }
    },

    // 登录
    {
        path: '/login',
        name: 'login',
        component: login,
        meta: {
            index: 0,
            title: '登录'
        }
    },

            // 注册
        {
            path: '/register',
            name: 'register',
            component: register,
            meta: {
                index: 0,
                title: '注册'
            }
        },
    	
	
    // 忘记密码
    {
        path: '/forgot',
        name: "forgot",
        component: forgot,
        meta: {
            index: 0,
            title: '忘记密码'
        }
    },

    // 修改密码
    {
        path: '/user/password',
        name: "password",
        component: () => import("../views/user/password.vue"),
        meta: {
            index: 0,
            title: '修改密码'
        }
    },

    // 视频播放页
    {
        path: "/media/video",
        name: "video",
        component: () => import('../views/media/video.vue'),
        meta: {
            index: 0,
            title: "视频"
        }
    },

    // 音频播放页
    {
        path: "/media/audio",
        name: "audio",
        component: () => import('../views/media/audio.vue'),
        meta: {
            index: 0,
            title: "音频"
        }
    },

    
    
                // 轮播图路由
        {
            path: '/slides/table',
            name: 'slides_table',
            component: () => import('../views/slides/table.vue'),
            meta: {
                index: 0,
                title: '轮播图列表'
            }
        },
        {
            path: '/slides/view',
            name: 'slides_view',
            component: () => import('../views/slides/view.vue'),
            meta: {
                index: 0,
                title: '轮播图详情'
            }
        },
                    // 文章路由
            {
                path: '/article/table',
                name: 'article_table',
                component: () => import('../views/article/table.vue'),
                meta: {
                    index: 0,
                    title: '资讯信息列表'
                }
            },
            {
                path: '/article/view',
                name: 'article_view',
                component: () => import('../views/article/view.vue'),
                meta: {
                    index: 0,
                    title: '资讯信息详情'
                }
            },

            // 文章分类路由
            {
                path: '/article_type/table',
                name: 'article_type_table',
                component: () => import('../views/article_type/table.vue'),
                meta: {
                    index: 0,
                    title: '资讯信息分类列表'
                }
            },
            {
                path: '/article_type/view',
                name: 'article_type_view',
                component: () => import('../views/article_type/view.vue'),
                meta: {
                    index: 0,
                    title: '资讯信息分类详情'
                }
            },
                            
    
    
            // 公告路由
        {
            path: '/notice/table',
            name: 'notice_table',
            component: () => import('../views/notice/table.vue'),
            meta: {
                index: 0,
                title: '通知公告列表'
            }
        },
        {
            path: '/notice/view',
            name: 'notice_view',
            component: () => import('../views/notice/view.vue'),
            meta: {
                index: 0,
                title: '通知公告详情'
            }
        },
                    // 科目模块-考试路由
        {
            path: '/exam_subject/exams_table',
            name: 'exam_table',
            component: () => import('../views/exam_subject/exams_table.vue'),
            meta: {
                index: 0,
                title: '在线测试'
            }
        },
        // 自动题库
        {
            path: '/exam_subject/genQuestion',
            name: 'exam_genQuestion',
            component: () => import('../views/exam_subject/genQuestion.vue'),
            meta: {
                index: 0,
                title: '自动题库'
            }
        },
        //科目模块-考试详情
        {
            path: '/exam_subject/exams_view',
            name: 'exam_view',
            component: () => import('../views/exam_subject/exams_view.vue'),
            meta: {
                index: 0,
                title: '考试详情'
            }
        },
        //科目列表
        {
            path: '/exam_subject/table',
            name: 'subject_table',
            component: () => import('../views/exam_subject/table.vue'),
            meta: {
                index: 0,
                title: '科目列表'
            }
        },
        //科目详情
        {
            path: '/exam_subject/view',
            name: 'subject_view',
            component: () => import('../views/exam_subject/view.vue'),
            meta: {
                index: 0,
                title: '科目详情'
            }
        },
        {
            path: '/exam_subject/exams_db',
            name: 'exams_db',
            component: () => import('../views/exam_subject/exams_db.vue'),
            meta: {
                index: 0,
                title: '试题库'
            }
        },
        {
            path: '/exam_subject/wrong_list',
            name: 'wrong_list',
            component: () => import('../views/exam_subject/wrong_list.vue'),
            meta: {
                index: 0,
                title: '错题记录'
            }
        },
        {
            path: '/exam_subject/answer_wrong_view',
            name: 'question_view',
            component: () => import('../views/exam_subject/answer_wrong_view.vue'),
            meta: {
                index: 0,
                title: '错题详情'
            }
        },
        {
            path: '/exam_subject/question_table',
            name: 'question_table_table',
            component: () => import('../views/exam_subject/question_table.vue'),
            meta: {
                index: 0,
                title: '题库列表'
            }
        },
        {
            path: '/exam_subject/question_view',
            name: 'question_view_view',
            component: () => import('../views/exam_subject/question_view.vue'),
            meta: {
                index: 0,
                title: '题库详情'
            }
        },

        {
            path: '/exam_subject/question_database_table',
            name: 'question_database_table',
            component: () => import('../views/exam_subject/question_database_table.vue'),
            meta: {
                index: 0,
                title: '题库列表'
            }
        },
        {
            path: '/exam_subject/question_database_view',
            name: 'question_database_view',
            component: () => import('../views/exam_subject/question_database_view.vue'),
            meta: {
                index: 0,
                title: '题库详情'
            }
        },
        //科目模块-答题
        {
            path: '/exam_subject/answer_view',
            name: 'answer_view_view',
            component: () => import('../views/exam_subject/answer_view.vue'),
            meta: {
                index: 0,
                title: '答题'
            }
        },
        //科目模块-评分列表
        {
            path: '/exam_subject/score_table',
            name: 'score_table_table',
            component: () => import('../views/exam_subject/score_table.vue'),
            meta: {
                index: 0,
                title: '评分列表'
            }
        },
        //科目模块-评分详情
        {
            path: '/exam_subject/score_view',
            name: 'score_view_view',
            component: () => import('../views/exam_subject/score_view.vue'),
            meta: {
                index: 0,
                title: '评分详情'
            }
        },
    	    
            // 评论路由
        {
            path: '/comment/table',
            name: 'comment_table',
            component: () => import('../views/comment/table.vue'),
            meta: {
                index: 0,
                title: '评论列表'
            }
        },
        {
            path: '/comment/view',
            name: 'comment_view',
            component: () => import('../views/comment/view.vue'),
            meta: {
                index: 0,
                title: '评论详情'
            }
        },
        	            // 教师用户路由
        {
            path: '/teacher_user/table',
            name: 'teacher_user_table',
            component: () => import('../views/teacher_user/table.vue'),
            meta: {
                index: 0,
                title: '教师用户列表'
            }
        },
        {
            path: '/teacher_user/view',
            name: 'teacher_user_view',
            component: () => import('../views/teacher_user/view.vue'),
            meta: {
                index: 0,
                title: '教师用户详情'
            }
        },
						            // 学生用户路由
        {
            path: '/student_users/table',
            name: 'student_users_table',
            component: () => import('../views/student_users/table.vue'),
            meta: {
                index: 0,
                title: '学生用户列表'
            }
        },
        {
            path: '/student_users/view',
            name: 'student_users_view',
            component: () => import('../views/student_users/view.vue'),
            meta: {
                index: 0,
                title: '学生用户详情'
            }
        },
						            // 课程信息路由
        {
            path: '/course_information/table',
            name: 'course_information_table',
            component: () => import('../views/course_information/table.vue'),
            meta: {
                index: 0,
                title: '课程信息列表'
            }
        },
        {
            path: '/course_information/view',
            name: 'course_information_view',
            component: () => import('../views/course_information/view.vue'),
            meta: {
                index: 0,
                title: '课程信息详情'
            }
        },
						            // 班级信息路由
        {
            path: '/class_information/table',
            name: 'class_information_table',
            component: () => import('../views/class_information/table.vue'),
            meta: {
                index: 0,
                title: '班级信息列表'
            }
        },
        {
            path: '/class_information/view',
            name: 'class_information_view',
            component: () => import('../views/class_information/view.vue'),
            meta: {
                index: 0,
                title: '班级信息详情'
            }
        },
						            // 课程类型路由
        {
            path: '/course_type/table',
            name: 'course_type_table',
            component: () => import('../views/course_type/table.vue'),
            meta: {
                index: 0,
                title: '课程类型列表'
            }
        },
        {
            path: '/course_type/view',
            name: 'course_type_view',
            component: () => import('../views/course_type/view.vue'),
            meta: {
                index: 0,
                title: '课程类型详情'
            }
        },
						            // 选课申请路由
        {
            path: '/application_for_course_selection/table',
            name: 'application_for_course_selection_table',
            component: () => import('../views/application_for_course_selection/table.vue'),
            meta: {
                index: 0,
                title: '选课申请列表'
            }
        },
        {
            path: '/application_for_course_selection/view',
            name: 'application_for_course_selection_view',
            component: () => import('../views/application_for_course_selection/view.vue'),
            meta: {
                index: 0,
                title: '选课申请详情'
            }
        },
						            // 选课信息路由
        {
            path: '/course_selection_information/table',
            name: 'course_selection_information_table',
            component: () => import('../views/course_selection_information/table.vue'),
            meta: {
                index: 0,
                title: '选课信息列表'
            }
        },
        {
            path: '/course_selection_information/view',
            name: 'course_selection_information_view',
            component: () => import('../views/course_selection_information/view.vue'),
            meta: {
                index: 0,
                title: '选课信息详情'
            }
        },
						            // 提问信息路由
        {
            path: '/question_information/table',
            name: 'question_information_table',
            component: () => import('../views/question_information/table.vue'),
            meta: {
                index: 0,
                title: '提问信息列表'
            }
        },
        {
            path: '/question_information/view',
            name: 'question_information_view',
            component: () => import('../views/question_information/view.vue'),
            meta: {
                index: 0,
                title: '提问信息详情'
            }
        },
						            // 回答信息路由
        {
            path: '/answer_information/table',
            name: 'answer_information_table',
            component: () => import('../views/answer_information/table.vue'),
            meta: {
                index: 0,
                title: '回答信息列表'
            }
        },
        {
            path: '/answer_information/view',
            name: 'answer_information_view',
            component: () => import('../views/answer_information/view.vue'),
            meta: {
                index: 0,
                title: '回答信息详情'
            }
        },
						            // 课程反馈路由
        {
            path: '/course_feedback/table',
            name: 'course_feedback_table',
            component: () => import('../views/course_feedback/table.vue'),
            meta: {
                index: 0,
                title: '课程反馈列表'
            }
        },
        {
            path: '/course_feedback/view',
            name: 'course_feedback_view',
            component: () => import('../views/course_feedback/view.vue'),
            meta: {
                index: 0,
                title: '课程反馈详情'
            }
        },
						            // 课程作业路由
        {
            path: '/course_work/table',
            name: 'course_work_table',
            component: () => import('../views/course_work/table.vue'),
            meta: {
                index: 0,
                title: '课程作业列表'
            }
        },
        {
            path: '/course_work/view',
            name: 'course_work_view',
            component: () => import('../views/course_work/view.vue'),
            meta: {
                index: 0,
                title: '课程作业详情'
            }
        },
						            // 完成作业路由
        {
            path: '/finish_the_job/table',
            name: 'finish_the_job_table',
            component: () => import('../views/finish_the_job/table.vue'),
            meta: {
                index: 0,
                title: '完成作业列表'
            }
        },
        {
            path: '/finish_the_job/view',
            name: 'finish_the_job_view',
            component: () => import('../views/finish_the_job/view.vue'),
            meta: {
                index: 0,
                title: '完成作业详情'
            }
        },
						            // 作业批改路由
        {
            path: '/homework_correction/table',
            name: 'homework_correction_table',
            component: () => import('../views/homework_correction/table.vue'),
            meta: {
                index: 0,
                title: '作业批改列表'
            }
        },
        {
            path: '/homework_correction/view',
            name: 'homework_correction_view',
            component: () => import('../views/homework_correction/view.vue'),
            meta: {
                index: 0,
                title: '作业批改详情'
            }
        },
						            // 评估记录路由
        {
            path: '/assessment_record/table',
            name: 'assessment_record_table',
            component: () => import('../views/assessment_record/table.vue'),
            meta: {
                index: 0,
                title: '评估记录列表'
            }
        },
        {
            path: '/assessment_record/view',
            name: 'assessment_record_view',
            component: () => import('../views/assessment_record/view.vue'),
            meta: {
                index: 0,
                title: '评估记录详情'
            }
        },
						            // 进度记录路由
        {
            path: '/progress_records/table',
            name: 'progress_records_table',
            component: () => import('../views/progress_records/table.vue'),
            meta: {
                index: 0,
                title: '进度记录列表'
            }
        },
        {
            path: '/progress_records/view',
            name: 'progress_records_view',
            component: () => import('../views/progress_records/view.vue'),
            meta: {
                index: 0,
                title: '进度记录详情'
            }
        },
						            // 资料信息路由
        {
            path: '/information/table',
            name: 'information_table',
            component: () => import('../views/information/table.vue'),
            meta: {
                index: 0,
                title: '资料信息列表'
            }
        },
        {
            path: '/information/view',
            name: 'information_view',
            component: () => import('../views/information/view.vue'),
            meta: {
                index: 0,
                title: '资料信息详情'
            }
        },
						            // 资料类型路由
        {
            path: '/data_type/table',
            name: 'data_type_table',
            component: () => import('../views/data_type/table.vue'),
            meta: {
                index: 0,
                title: '资料类型列表'
            }
        },
        {
            path: '/data_type/view',
            name: 'data_type_view',
            component: () => import('../views/data_type/view.vue'),
            meta: {
                index: 0,
                title: '资料类型详情'
            }
        },
						            // 口语录音路由
        {
            path: '/oral_recording/table',
            name: 'oral_recording_table',
            component: () => import('../views/oral_recording/table.vue'),
            meta: {
                index: 0,
                title: '口语录音列表'
            }
        },
        {
            path: '/oral_recording/view',
            name: 'oral_recording_view',
            component: () => import('../views/oral_recording/view.vue'),
            meta: {
                index: 0,
                title: '口语录音详情'
            }
        },
						    	    // 用户路由
    {
        path: '/user/table',
        name: 'user_table',
        component: () => import('../views/user/table.vue'),
        meta: {
            index: 0,
            title: '用户列表'
        }
    },
    {
        path: '/user/view',
        name: 'user_view',
        component: () => import('../views/user/view.vue'),
        meta: {
            index: 0,
            title: '用户详情'
        }
    },
    {
        path: '/user/info',
        name: 'user_info',
        component: () => import('../views/user/info.vue'),
        meta: {
            index: 0,
            title: '个人信息'
        }
    },
    // 用户组路由
    {
        path: '/user_group/table',
        name: 'user_group_table',
        component: () => import('../views/user_group/table.vue'),
        meta: {
            index: 0,
            title: '用户组列表'
        }
    },
    {
        path: '/user_group/view',
        name: 'user_group_view',
        component: () => import('../views/user_group/view.vue'),
        meta: {
            index: 0,
            title: '用户组详情'
        }
    }
]

const router = new VueRouter({
    mode: 'hash',
    base: process.env.BASE_URL,
    routes
})

router.beforeEach((to, from, next) => {
    let token = to.query.token;
    if (token) {
        $.db.set("token", token, 120);
    }
    next();
})

router.afterEach((to, from, next) => {
    let title = "在线英语口语学习平台-admin";
    document.title = title;
})

export default router
