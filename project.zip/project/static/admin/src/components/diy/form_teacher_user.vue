<template>
	<div>
			<el-form-item v-if="$check_register_field('add','teacher_id','/teacher_user/view')" label="教师工号" prop="teacher_id">
				<el-input id="teacher_id" v-model="form['teacher_id']" placeholder="请输入教师工号" ></el-input>
				</el-form-item>
				<el-form-item v-if="$check_register_field('add','teachers_name','/teacher_user/view')" label="教师姓名" prop="teachers_name">
				<el-input id="teachers_name" v-model="form['teachers_name']" placeholder="请输入教师姓名" ></el-input>
				</el-form-item>
				<el-form-item v-if="$check_register_field('add','qualification_screenshot','/teacher_user/view')" label="资格截图" prop="qualification_screenshot">
				<el-upload id="qualification_screenshot" class="avatar-uploader" drag
			accept="image/gif, image/jpeg, image/png, image/jpg" action="" :http-request="uploadimg_qualification_screenshot"
			:show-file-list="false" >
			<img v-if="form['qualification_screenshot']" :src="$fullUrl(form['qualification_screenshot'])" class="avatar">
			<i v-else class="el-icon-plus avatar-uploader-icon"></i>
		</el-upload>
				</el-form-item>
	
	</div>
</template>

<script>
	import mixin from "@/mixins/component.js";

	export default {
		mixins: [mixin],
		props:{

			form:{
				type: Object,
				default: function(){
					return {
							"teacher_id":  '' ,
								"teachers_name":  '' ,
								"qualification_screenshot":  '' ,
						}
				}
			},

		},
		data() {
			return {
				field: "teacher_user_id",
				url_add: "~/api/teacher_user/add?",
				url_set: "~/api/teacher_user/set?",
				url_upload: "~/api/teacher_user/upload?",

										rules: {
					"teacher_id": [    {required: true,message: '教师工号不能为空'},  ],
					"teachers_name": [    {required: true,message: '教师姓名不能为空'},  ],
					"qualification_screenshot": [    {required: true,message: '资格截图不能为空'},  ],
				}

			}
		},
		methods: {
	
	
		
	
					/**
			 * 上传资格截图
			 * @param {Object} param 图片参数
			 */
			uploadimg_qualification_screenshot(param) {
								this.uploadFile(param.file, "qualification_screenshot");
							},
	
	
			},
		created() {
								}
	}
</script>
