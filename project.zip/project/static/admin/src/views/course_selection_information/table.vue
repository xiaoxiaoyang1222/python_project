<template>
	<el-main class="bg table_wrap comtabel_t">
		<el-form label-position="right" :model="query" class="form p_4" label-width="120">
			<el-row class="rows row1">



										<el-col :xs="24" :sm="24" :lg="8" class="el_form_search_wrap">
					<el-form-item label="课程名称">
									<el-input v-model="query.course_name"></el-input>
								</el-form-item>
				</el-col>
															<el-col :xs="24" :sm="24" :lg="8" class="el_form_search_wrap">
					<el-form-item label="班级名称">
									<el-input v-model="query.class_name"></el-input>
								</el-form-item>
				</el-col>
																					<el-col :xs="24" :sm="24" :lg="8" class="el_form_search_wrap">
					<el-form-item label="学生姓名">
									<el-input v-model="query.student_name"></el-input>
								</el-form-item>
				</el-col>
													</el-row>
	<el-row class="rows row2">

		<el-col :xs="24" :sm="24" :lg="24" class="search_btn_wrap search_btns">

				<el-col :xs="24" :sm="10" :lg="8" class="search_btn_1 search_btn_wrap_1 btns">

										<el-button type="primary" @click="search()" class="search_btn_find">查询</el-button>
						<el-button @click="reset()" style="margin-right: 74px;" class="search_btn_reset">重置</el-button>
																		

						<el-button v-if="$check_action('/course_selection_information/table','del') || $check_action('/course_selection_information/view','del')" class="search_btn_del" type="danger" @click="delInfo()">删除</el-button>
								
				</el-col>
		</el-col>
	</el-row >

		</el-form>
				<el-table :data="list" @selection-change="selectionChange" @sort-change="$sortChange" style="width: 100%" id="dataTable">
					<el-table-column fixed type="selection" tooltip-effect="dark" width="55">
			</el-table-column>
				<el-table-column prop="course_number" @sort-change="$sortChange" label="课程编号" 				v-if="$check_field('get','course_number')" min-width="200">
					</el-table-column>
					<el-table-column prop="course_name" @sort-change="$sortChange" label="课程名称" 				v-if="$check_field('get','course_name')" min-width="200">
					</el-table-column>
					<el-table-column prop="course_type" @sort-change="$sortChange" label="课程类型" 				v-if="$check_field('get','course_type')" min-width="200">
					</el-table-column>
					<el-table-column prop="course_duration" @sort-change="$sortChange" label="课程时间" 				v-if="$check_field('get','course_duration')" min-width="200">
					</el-table-column>
					<el-table-column prop="class_name" @sort-change="$sortChange" label="班级名称" 				v-if="$check_field('get','class_name')" min-width="200">
					</el-table-column>
					<el-table-column prop="course_teacher" @sort-change="$sortChange" label="课程教师" 				v-if="$check_field('get','course_teacher')" min-width="200">
						<template slot-scope="scope">
					{{ get_user_course_teacher(scope.row['course_teacher']) }}
				</template>
					</el-table-column>
					<el-table-column prop="teacher_id" @sort-change="$sortChange" label="教师工号" 				v-if="$check_field('get','teacher_id')" min-width="200">
					</el-table-column>
					<el-table-column prop="teachers_name" @sort-change="$sortChange" label="教师姓名" 				v-if="$check_field('get','teachers_name')" min-width="200">
					</el-table-column>
					<el-table-column prop="student_users" @sort-change="$sortChange" label="学生用户" 				v-if="$check_field('get','student_users')" min-width="200">
						<template slot-scope="scope">
					{{ get_user_student_users(scope.row['student_users']) }}
				</template>
					</el-table-column>
					<el-table-column prop="student_name" @sort-change="$sortChange" label="学生姓名" 				v-if="$check_field('get','student_name')" min-width="200">
					</el-table-column>
					<el-table-column prop="student_gender" @sort-change="$sortChange" label="学生性别" 				v-if="$check_field('get','student_gender')" min-width="200">
					</el-table-column>
					<el-table-column prop="mobile_phone_number" @sort-change="$sortChange" label="手机号码" 				v-if="$check_field('get','mobile_phone_number')" min-width="200">
					</el-table-column>
					<el-table-column prop="number_of_enrolment" @sort-change="$sortChange" label="报名人数" 				v-if="$check_field('get','number_of_enrolment')" min-width="200">
					</el-table-column>
	


            <el-table-column sortable prop="create_time" label="创建时间" min-width="200">
                <template slot-scope="scope">
                	{{ $toTime(scope.row["create_time"],"yyyy-MM-dd hh:mm:ss") }}
                </template>
            </el-table-column>

			<el-table-column sortable prop="update_time" label="更新时间" min-width="200">
                <template slot-scope="scope">
                	{{ $toTime(scope.row["update_time"],"yyyy-MM-dd hh:mm:ss") }}
                </template>
			</el-table-column>







			<el-table-column fixed="right" label="操作" min-width="200" v-if="$check_action('/course_selection_information/table','set') || $check_action('/course_selection_information/view','set') || $check_action('/course_selection_information/view','get') 
						|| $check_action('/question_information/table','add') || $check_action('/question_information/view','add') 
						|| $check_action('/course_feedback/table','add') || $check_action('/course_feedback/view','add') 
						|| $check_action('/course_work/table','add') || $check_action('/course_work/view','add') 
						|| $check_action('/assessment_record/table','add') || $check_action('/assessment_record/view','add') 
						|| $check_action('/progress_records/table','add') || $check_action('/progress_records/view','add') 
						|| $check_action('/oral_recording/table','add') || $check_action('/oral_recording/view','add') 
						" >


				<template slot-scope="scope">
					<div class="view_a">
					<router-link class="e-button el-button--small is-plain el-button--success" style="margin: 5px !important;"
					v-if="$check_action('/course_selection_information/table','set') || $check_action('/course_selection_information/view','set') || $check_action('/course_selection_information/view','get')"
						:to="'./view?' + field + '=' + scope.row[field]"
						 size="small">
						<span>详情</span>
					</router-link>
						<!--跨表按钮-->
										<el-button class="e-button el-button--small is-plain el-button--primary" style="margin: 5px !important;" size="small" @click="to_table(scope.row,'/question_information/view')" v-if="($check_action('/question_information/table','add') || $check_action('/question_information/view','add')) && !scope.row['question_information_limit']">
						<span>提问</span>
					</el-button>
													<el-button class="e-button el-button--small is-plain el-button--primary" style="margin: 5px !important;" size="small" @click="to_table(scope.row,'/course_feedback/view')" v-if="($check_action('/course_feedback/table','add') || $check_action('/course_feedback/view','add')) && !scope.row['course_feedback_limit']">
						<span>反馈</span>
					</el-button>
													<el-button class="e-button el-button--small is-plain el-button--primary" style="margin: 5px !important;" size="small" @click="to_table(scope.row,'/course_work/view')" v-if="($check_action('/course_work/table','add') || $check_action('/course_work/view','add')) && !scope.row['course_work_limit']">
						<span>作业</span>
					</el-button>
													<el-button class="e-button el-button--small is-plain el-button--primary" style="margin: 5px !important;" size="small" @click="to_table(scope.row,'/assessment_record/view')" v-if="($check_action('/assessment_record/table','add') || $check_action('/assessment_record/view','add')) && !scope.row['assessment_record_limit']">
						<span>评估</span>
					</el-button>
													<el-button class="e-button el-button--small is-plain el-button--primary" style="margin: 5px !important;" size="small" @click="to_table(scope.row,'/progress_records/view')" v-if="($check_action('/progress_records/table','add') || $check_action('/progress_records/view','add')) && !scope.row['progress_records_limit']">
						<span>进度</span>
					</el-button>
													<el-button class="e-button el-button--small is-plain el-button--primary" style="margin: 5px !important;" size="small" @click="to_table(scope.row,'/oral_recording/view')" v-if="($check_action('/oral_recording/table','add') || $check_action('/oral_recording/view','add')) && !scope.row['oral_recording_limit']">
						<span>录音</span>
					</el-button>
										</div>
				</template>
			</el-table-column>

		</el-table>

		<!-- 分页器 -->
		<div class="mt text_center">
			<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page="query.page" :page-sizes="[7, 10, 30, 100]" :page-size="query.size"
				layout="total, sizes, prev, pager, next, jumper" :total="count">
			</el-pagination>
		</div>
		<!-- /分页器 -->
													
		<div class="modal_wrap" v-if="showModal">
			<div class="modal_box">
				<!-- <div class="modal_box_close" @click="closeModal">X</div> -->
				<p class="modal_box_title">重要提醒</p>
				<p class="modal_box_text">当前有数据达到预警值！</p>
				<p class="modal_box_text">{{ message }}</p>
				<div class="btn_box">
					<span @click="closeModal">取消</span>
					<span @click="closeModal">确定</span>
				</div>
			</div>
		</div>


	</el-main>
</template>
<script>
	import mixin from "@/mixins/page.js";

	export default {
		mixins: [mixin],
		data() {
			return {
				// 弹框
				showModal: false,
				// 获取数据地址
				url_get_list: "~/api/course_selection_information/get_list?like=0",
				url_del: "~/api/course_selection_information/del?",

				// 字段ID
				field: "course_selection_information_id",

				// 查询
				query: {
					"size": 7,
					"page": 1,
									"course_name": "",
													"class_name": "",
															"student_name": "",
											"login_time": "",
					"create_time": "",
					"orderby": `create_time desc`
				},

				// 数据
				list: [],
																															// 用户列表
				list_user_course_teacher: [],
													// 用户列表
				list_user_student_users: [],
													message: '',
			}
		},
		methods: {
			// 关闭弹框
			closeModal(){
				this.showModal = false;
				},
			/**
			 * @description 获取到列表事件
			 * @param {Object} res 响应结果
			 */
			get_list_after: function get_list_after(res, func, url) {
				let _this = this
													_this.list.map((item) => {
					let param = {
						source_table: "course_selection_information",
						source_id: item.course_selection_information_id,
						source_user_id: _this.user.user_id
					};
					if(item.question_information_limit_times > 0){
						_this.$get("~/api/question_information/count?",param,(result)=>{
							if(result){
								if(result.result >= item.question_information_limit_times){
									_this.$set(item,'question_information_limit',true);
								}else{
									_this.$set(item,'question_information_limit',false);
								}
							}
						})
					}else{
						_this.$set(item,'question_information_limit',false);
					}
					Object.assign(item, param)
				})
								_this.list.map((item) => {
					let param = {
						source_table: "course_selection_information",
						source_id: item.course_selection_information_id,
						source_user_id: _this.user.user_id
					};
					if(item.course_feedback_limit_times > 0){
						_this.$get("~/api/course_feedback/count?",param,(result)=>{
							if(result){
								if(result.result >= item.course_feedback_limit_times){
									_this.$set(item,'course_feedback_limit',true);
								}else{
									_this.$set(item,'course_feedback_limit',false);
								}
							}
						})
					}else{
						_this.$set(item,'course_feedback_limit',false);
					}
					Object.assign(item, param)
				})
								_this.list.map((item) => {
					let param = {
						source_table: "course_selection_information",
						source_id: item.course_selection_information_id,
						source_user_id: _this.user.user_id
					};
					if(item.course_work_limit_times > 0){
						_this.$get("~/api/course_work/count?",param,(result)=>{
							if(result){
								if(result.result >= item.course_work_limit_times){
									_this.$set(item,'course_work_limit',true);
								}else{
									_this.$set(item,'course_work_limit',false);
								}
							}
						})
					}else{
						_this.$set(item,'course_work_limit',false);
					}
					Object.assign(item, param)
				})
								_this.list.map((item) => {
					let param = {
						source_table: "course_selection_information",
						source_id: item.course_selection_information_id,
						source_user_id: _this.user.user_id
					};
					if(item.assessment_record_limit_times > 0){
						_this.$get("~/api/assessment_record/count?",param,(result)=>{
							if(result){
								if(result.result >= item.assessment_record_limit_times){
									_this.$set(item,'assessment_record_limit',true);
								}else{
									_this.$set(item,'assessment_record_limit',false);
								}
							}
						})
					}else{
						_this.$set(item,'assessment_record_limit',false);
					}
					Object.assign(item, param)
				})
								_this.list.map((item) => {
					let param = {
						source_table: "course_selection_information",
						source_id: item.course_selection_information_id,
						source_user_id: _this.user.user_id
					};
					if(item.progress_records_limit_times > 0){
						_this.$get("~/api/progress_records/count?",param,(result)=>{
							if(result){
								if(result.result >= item.progress_records_limit_times){
									_this.$set(item,'progress_records_limit',true);
								}else{
									_this.$set(item,'progress_records_limit',false);
								}
							}
						})
					}else{
						_this.$set(item,'progress_records_limit',false);
					}
					Object.assign(item, param)
				})
								_this.list.map((item) => {
					let param = {
						source_table: "course_selection_information",
						source_id: item.course_selection_information_id,
						source_user_id: _this.user.user_id
					};
					if(item.oral_recording_limit_times > 0){
						_this.$get("~/api/oral_recording/count?",param,(result)=>{
							if(result){
								if(result.result >= item.oral_recording_limit_times){
									_this.$set(item,'oral_recording_limit',true);
								}else{
									_this.$set(item,'oral_recording_limit',false);
								}
							}
						})
					}else{
						_this.$set(item,'oral_recording_limit',false);
					}
					Object.assign(item, param)
				})
																																																																															},
			get_list_before(param){
				var user_group = this.user.user_group;
				if(user_group != "管理员"){
						let sqlwhere = "(";
																																			if(user_group=="教师用户"){
						sqlwhere+= "course_teacher = " + this.user.user_id + " or ";
					}
																							if(user_group=="学生用户"){
						sqlwhere+= "student_users = " + this.user.user_id + " or ";
					}
																														if (sqlwhere.length>1){
						sqlwhere = sqlwhere.substr(0,sqlwhere.length-4);
						sqlwhere += ")";
						param["sqlwhere"] = sqlwhere;
					}
					}
				return param;
			},

																										



														/**
			 * 获取教师用户用户列表
			 */
			async get_list_user_course_teacher() {
				var json = await this.$get("~/api/user/get_list?user_group=教师用户");
				if(json.result && json.result.list){
					this.list_user_course_teacher = json.result.list;
				}
				else if(json.error){
					console.error(json.error);
				}
			},

			get_user_course_teacher(id){
				var obj = this.list_user_course_teacher.getObj({"user_id":id});
				var ret = "";
				if(obj){
					ret = obj.nickname+"-"+obj.username;
					// if(obj.nickname){
					// 	ret = obj.nickname;
					// }
					// else{
					// 	ret = obj.username;
					// }
				}
				return ret;
			},
										/**
			 * 获取学生用户用户列表
			 */
			async get_list_user_student_users() {
				var json = await this.$get("~/api/user/get_list?user_group=学生用户");
				if(json.result && json.result.list){
					this.list_user_student_users = json.result.list;
				}
				else if(json.error){
					console.error(json.error);
				}
			},

			get_user_student_users(id){
				var obj = this.list_user_student_users.getObj({"user_id":id});
				var ret = "";
				if(obj){
					ret = obj.nickname+"-"+obj.username;
					// if(obj.nickname){
					// 	ret = obj.nickname;
					// }
					// else{
					// 	ret = obj.username;
					// }
				}
				return ret;
			},
												},
				created() {
																	this.get_list_user_course_teacher();
												this.get_list_user_student_users();
											}
	}
</script>

<style type="text/css">
	.bg {
		background: white;
	}

	.form.p_4 {
		padding: 1rem;
	}

	.form .el-input {
		width: initial;
	}

	.mt {
		margin-top: 1rem;
	}

	.text_center {
		text-align: center;
	}

	.float-right {
		float: right;
	}


	.modal_wrap{
		width: 100vw;
		height: 100vh;
		position: fixed;
		top: 0;
		left: 0;
		background: rgba(0,0,0,0.5);
		z-index: 9999999999;
	}
	.modal_wrap .modal_box{
		width: 400px;
		height: auto;
		background: url("../../assets/modal_bg.jpg") no-repeat center;
		background-size: cover;
		position: absolute;
		top: 50%;
		left: 50%;
		margin-left: -200px;
		margin-top: -100px;
		border-radius: 10px;
		padding: 10px;
		}
	.modal_wrap .modal_box .modal_box_close{
		font-size: 20px;
		position: absolute;
		top: 10px;
		right: 10px;
		cursor: pointer;
		}
	.modal_wrap .modal_box .modal_box_title{
	  text-align: center;
    font-size: 18px;
    margin: 16px auto;
    color: #fff;
    border-bottom: 1px solid rgba(117, 116, 116,0.5);
    padding-bottom: 16px;
    width: 356px;
		}
	.modal_wrap .modal_box .modal_box_text{
		text-align: center;
		font-size: 14px;
		color: #fff;
		margin: 5px auto;
		width: 90%;
		}
	.modal_wrap .modal_box .btn_box{
		display: flex;
		flex-direction: row;
		justify-content: center;
		margin-top: 42px;
		margin-bottom: 20px;
		}
			.modal_wrap .modal_box .btn_box span{
				display: inline-block;
				width: 80px;
				height: 30px;
				line-height: 30px;
				text-align: center;
				border: 1px solid #ccc;
				font-size: 14px;
				cursor: pointer;
				color: #fff;
			}
	.modal_wrap .modal_box .btn_box span:nth-child(2){
		background: #409EFF;
		color: #fff;
		border-color: #409EFF;
		margin-left: 15px;
	}
	.el-date-editor .el-range-separator{
		width: 10% !important;
	}
</style>
