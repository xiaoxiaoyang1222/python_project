from app.core.mysql import Service


# 资料类型服务
class Data_type(Service):
    def __init__(self, *config):
        """
        构造函数
        @param {Object} config 配置参数
        """
        if config:
            config_temp = config[0]
        else:
            config_temp = {
                # 操作的表
                "table": "data_type",
                # 分页大小
                "size": 30,
                "page": 1,
            }
        super(Data_type , self).__init__(config_temp)
