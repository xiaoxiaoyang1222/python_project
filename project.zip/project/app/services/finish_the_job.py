from app.core.mysql import Service


# 完成作业服务
class Finish_the_job(Service):
    def __init__(self, *config):
        """
        构造函数
        @param {Object} config 配置参数
        """
        if config:
            config_temp = config[0]
        else:
            config_temp = {
                # 操作的表
                "table": "finish_the_job",
                # 分页大小
                "size": 30,
                "page": 1,
            }
        super(Finish_the_job , self).__init__(config_temp)
