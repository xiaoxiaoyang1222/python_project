from app.core import controller
from app.service import service_select

controllerClass = getattr(controller, "Controller")

# 口语录音
class Oral_recording(controllerClass):
    def __init__(self, config={}):
        """
        构造函数
        @param {Object} config 配置参数
        """
        config_init = {
            # 选择的模板那路径模板
            "tpl": "./oral_recording/",
            # 选择的服务
            "service": "oral_recording",
        }
        config_temp = config
        config_temp.update(config_init)
        super(Oral_recording , self).__init__(config_temp)





