from app.core import controller
from app.service import service_select

controllerClass = getattr(controller, "Controller")

# 学生用户
class Student_users(controllerClass):
    def __init__(self, config={}):
        """
        构造函数
        @param {Object} config 配置参数
        """
        config_init = {
            # 选择的模板那路径模板
            "tpl": "./student_users/",
            # 选择的服务
            "service": "student_users",
        }
        config_temp = config
        config_temp.update(config_init)
        super(Student_users , self).__init__(config_temp)





