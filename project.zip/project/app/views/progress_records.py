from app.core import controller
from app.service import service_select

controllerClass = getattr(controller, "Controller")

# 进度记录
class Progress_records(controllerClass):
    def __init__(self, config={}):
        """
        构造函数
        @param {Object} config 配置参数
        """
        config_init = {
            # 选择的模板那路径模板
            "tpl": "./progress_records/",
            # 选择的服务
            "service": "progress_records",
        }
        config_temp = config
        config_temp.update(config_init)
        super(Progress_records , self).__init__(config_temp)





