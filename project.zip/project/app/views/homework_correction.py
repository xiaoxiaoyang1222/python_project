from app.core import controller
from app.service import service_select

controllerClass = getattr(controller, "Controller")

# 作业批改
class Homework_correction(controllerClass):
    def __init__(self, config={}):
        """
        构造函数
        @param {Object} config 配置参数
        """
        config_init = {
            # 选择的模板那路径模板
            "tpl": "./homework_correction/",
            # 选择的服务
            "service": "homework_correction",
        }
        config_temp = config
        config_temp.update(config_init)
        super(Homework_correction , self).__init__(config_temp)





