from app.core import controller
from app.service import service_select

controllerClass = getattr(controller, "Controller")

# 资料类型
class Data_type(controllerClass):
    def __init__(self, config={}):
        """
        构造函数
        @param {Object} config 配置参数
        """
        config_init = {
            # 选择的模板那路径模板
            "tpl": "./data_type/",
            # 选择的服务
            "service": "data_type",
        }
        config_temp = config
        config_temp.update(config_init)
        super(Data_type , self).__init__(config_temp)





