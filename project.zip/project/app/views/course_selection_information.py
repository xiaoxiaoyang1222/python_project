from app.core import controller
from app.service import service_select

controllerClass = getattr(controller, "Controller")

# 选课信息
class Course_selection_information(controllerClass):
    def __init__(self, config={}):
        """
        构造函数
        @param {Object} config 配置参数
        """
        config_init = {
            # 选择的模板那路径模板
            "tpl": "./course_selection_information/",
            # 选择的服务
            "service": "course_selection_information",
        }
        config_temp = config
        config_temp.update(config_init)
        super(Course_selection_information , self).__init__(config_temp)

    # 添加数据成功后
    def Add_after(self, ctx, result):
	    """
		添加数据前
		@param {Object} ctx http请求上下文
		@return {Object} 返回json-rpc格式结果
		"""
	    service = self.service
	    obj = service.Get_obj({}, {"orderby": "`course_selection_information_id` DESC"})
	    if obj:
	        # 计算
	        service.run("UPDATE `class_information` INNER JOIN `course_selection_information` ON class_information.class_name=course_selection_information.class_name SET class_information.class_size= class_information.class_size + course_selection_information.number_of_enrolment WHERE course_selection_information.course_selection_information_id=" + str(obj["course_selection_information_id"]))
	    return result




