from app.core import controller
from app.service import service_select

controllerClass = getattr(controller, "Controller")

# 评估记录
class Assessment_record(controllerClass):
    def __init__(self, config={}):
        """
        构造函数
        @param {Object} config 配置参数
        """
        config_init = {
            # 选择的模板那路径模板
            "tpl": "./assessment_record/",
            # 选择的服务
            "service": "assessment_record",
        }
        config_temp = config
        config_temp.update(config_init)
        super(Assessment_record , self).__init__(config_temp)





