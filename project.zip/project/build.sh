#!/bin/sh
if [ "$1" = "build" ];then
    mkdir /home/changsheng/project/project45987/project
    cp -a /home/changsheng/project/project45987/server/. /home/changsheng/project/project45987/project/
    cd /home/changsheng/project/project45987/project
    rm -rf /home/changsheng/project/project45987/server
    echo "执行成功"
fi
